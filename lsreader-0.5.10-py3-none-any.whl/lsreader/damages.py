import re
from datetime import datetime
from typing import Union

import numpy as np


class DamagesReader:
    def __init__(self, path: str) -> None:
        """ Read a damages file. """
        with open(path, "r") as infile:
            damages_lines = infile.readlines()

        self._hull_start_date: Union[datetime, None] = None
        self.sensors = {}
        self.units = {}
        self._date_index = None
        self._timevector = None

        print(f"Parsing header info...")
        line = damages_lines.pop(0).strip()
        while line.startswith("#"):
            self._parse_headerline(line)
            line = damages_lines.pop(0).strip()

        rows = len(damages_lines)
        cols = len(self.sensors)

        print(f"Reading data, {rows} rows, {cols} columns")
        data = np.empty((rows, cols), dtype=float)
        for i, row in enumerate(damages_lines):
            print(f"{(i+1)/len(damages_lines)*100:>5.1f}%", end="   \r")
            data[i] = np.array(row.split())
        print("")

        if self.date_index is not None:
            print("Converting date vector")
            self._timevector = np.array([datetime.strptime(str(int(x)), "%Y%m%d%H%M") for x in data[:,self.date_index]])
            print(f"Done, data is from: {self._timevector[0]} to {self._timevector[-1]}")
        else:
            print("Done")
        self._data = data

    def _parse_headerline(self, line: str) -> None:
        if line.startswith("# Hull Start Date:"):
            self._hull_start_date = datetime.strptime(line.split(":")[-1], "%Y%m%d")
            return

        col_def_with_unit = re.findall("# Col (.*): (.*) \((.*)\)", line)
        col_def_without_unit = re.findall("# Col (.*): (.*)()", line)

        if col_def_with_unit:
            col, sensor, unit = col_def_with_unit[0]
        elif col_def_without_unit:
            col, sensor, unit = col_def_without_unit[0]
        else:
            return

        if sensor == "Date":
            self.date_index = int(col) - 1

        # subtract 1 to get 
        self.sensors[int(col) - 1] = sensor
        self.units[int(col) - 1] = unit 

    def print_sensorlist(self) -> None:
        for index, name in self.sensors.items():
            print(index, name)

    @property
    def hull_start_date(self) -> Union[datetime, None]:
        return self._hull_start_date

    @property
    def sensors(self) -> dict:
        return self._sensors
    
    @sensors.setter
    def sensors(self, value: dict) -> None:
        self._sensors = value

    @property
    def units(self) -> dict:
        return self._units
    
    @units.setter
    def units(self, value: dict) -> None:
        self._units = value

    @property
    def timevector(self) -> np.ndarray:
        return self._timevector
    
    @property
    def data(self) -> np.ndarray:
        return self._data

    @property
    def date_index(self) -> Union[int, None]:
        return self._date_index
    
    @date_index.setter
    def date_index(self, value: int) -> None:
        self._date_index = int(value)