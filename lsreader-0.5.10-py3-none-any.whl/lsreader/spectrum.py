import numpy as np
import pandas as pd
from glob import glob
import matplotlib.pyplot as plt
import re
from scipy.signal import find_peaks
from datetime import datetime, timezone
from typing import List


class NoDataForChannelError(Exception):
    """ Special error to raise if the user requests data from a channel which we have not loaded data from """


class SpectraReader:
    def __init__(self, path: str):
        """ Read a set of spectrum .csv files from the given path """
        self.filenames = glob(f"{path}/*.csv")

        # use 
        self._timevectors = {} # each channel needs its own time vector
        self._datacube = {} # each channel needs its own data vector for both wavelength and reflectivity

        self._load_files()

    def _load_files(self):
        for filename in self.filenames:
            data = pd.read_csv(filename)

            try:
                parameters = {}

                this_time = re.findall('([0-9]{8}_[0-9]{6}_[0-9]{3})', data.columns[0])

                if this_time:
                    this_time = this_time[0]
                else:
                    this_time = "unknown"

                i = 0
                for row in data.itertuples():
                    temp_txt = re.findall(r'[a-zA-Z0-9\s]+\b(?=\s[^a-zA-Z0-9]*)', row._1)
                    temp_nr = re.findall(r'(\s[+-]?\d+(?:\.\d+)?)', row._1)

                    if temp_txt and temp_nr: 
                        temp_txt = temp_txt[0].lstrip(' ')
                        temp_nr = float(temp_nr[0].lstrip(' '))
                        parameters[temp_txt] = temp_nr

                    i += 1
                    if i > 11:
                        break

                channel = parameters["Channel number"]
                amplitude = parameters["Amplitude"]
                start_phase = parameters["Start Phase"]
                phase_step = parameters["PhaseStep"]
                delta = np.round(parameters["delta"], 4)
                lambda0 = np.round(parameters["lambda0"], 2)
                tcorr = np.round(parameters["Tcorr"], 2)

                spectrum = data[11:].values.astype(float)[:,0]

                x_wl = []
                for xn, val in enumerate(spectrum):
                    wl = 1500 + amplitude*np.cos(start_phase+(phase_step*xn)-delta) + lambda0 + tcorr
                    x_wl.append(wl)

                if not channel in self._timevectors:
                    self._timevectors[channel] = []
                
                if not channel in self._datacube:
                    self._datacube[channel] = []

                self._timevectors[channel].append(this_time)
                self._datacube[channel].append(np.array([np.array(x_wl), np.array(spectrum)]))

            except Exception as e:
                print(f"Couldn't parse: {filename}, skipping. Error: {e}")
                continue
        
        for channel, data in self._timevectors.items():
            self._timevectors[channel] = np.array(data)

        for channel, data in self._datacube.items():
            self._datacube[channel] = np.array(data)

    def get_data(self, channel: int, time_index: int) -> tuple:
        """ Get spectrum data
        
        Returns:
            tuple with:
                UTC timestamp (float)
                wavelength (array)
                reflection intensity (array)
        """
        if channel in self._timevectors:
            if time_index < len(self._timevectors[channel]):
                return self._timevectors[channel][time_index], self._datacube[channel][time_index][0], self._datacube[channel][time_index][1]
        else:
            raise NoDataForChannelError()
        
    @property
    def channels(self) -> List[int]:
        return list(self._timevectors.keys())