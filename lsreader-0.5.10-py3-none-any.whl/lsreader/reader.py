import numpy as np

from .reader_base import ReaderBase

try:
    from lspymove.quality.rules import Rule, RuleCollection, ErrorArrayTypes, DataType
    from lspymove.quality.data_quality.rule_list import all_rules
    lspymove_installed = True
except ImportError:
    lspymove_installed = False


class Reader(ReaderBase):
    """ Extended reader class to add quality metrics """
    def clear_data(self) -> None:
        self._total_quality_vector = None
        self._sensor_quality_matrix = None
        return super().clear_data()
    
    def check_quality(self):
        if not lspymove_installed:
            print(f"Can't run data quality check because lspymove is not installed")
            return
        collection = RuleCollection()
        collection.preloaded_data["this_reader"] = self

        for item in all_rules["passive"]:
            rule: Rule = item["rule"]
            if rule.error_array_type in [ErrorArrayTypes.TimeseriesArray, ErrorArrayTypes.TimeseriesArrayPerSensor, ErrorArrayTypes.BoolPerSensor]:
                rule._folder_name = "this_reader"
                if rule.data_type == DataType.Stat5 and self._reading_stats: # Stat5 rules also work for Stat30 data
                    rule.name = rule.name.replace("Stat5", "Stat")
                    collection.add_rule(rule)
                elif rule.data_type not in [DataType.Stat5, DataType.Stat30] and not self._reading_stats:
                    collection.add_rule(rule)

        for rule in collection.rules_list:
            rule.check()
            if not rule.is_checked: continue

            if rule.error_array_type is ErrorArrayTypes.TimeseriesArrayPerSensor:
                if self._sensor_quality_matrix is None:
                    self._sensor_quality_matrix = np.invert(rule.error_array)
                else:
                    self._sensor_quality_matrix = self._sensor_quality_matrix & np.invert(rule.error_array)
            elif rule.error_array_type is ErrorArrayTypes.TimeseriesArray:
                if self._total_quality_vector is None:
                    self._total_quality_vector = np.invert(rule.error_array)
                else:
                    self._total_quality_vector = self._total_quality_vector & np.invert(rule.error_array)
            elif rule.error_array_type is ErrorArrayTypes.BoolPerSensor:
                if self._sensor_quality_matrix is None:
                    self._sensor_quality_matrix = np.ones((self.num_sensors, len(self.timevector)), bool)
                    self._sensor_quality_matrix[rule.error_array==1,:] = 0
                else:
                    self._sensor_quality_matrix[rule.error_array==1,:] = 0

    @property
    def sensor_quality_matrix(self) -> np.ndarray:
        return self._sensor_quality_matrix
    
    @property
    def total_quality_matrix(self) -> np.ndarray:
        return self._total_quality_vector

                