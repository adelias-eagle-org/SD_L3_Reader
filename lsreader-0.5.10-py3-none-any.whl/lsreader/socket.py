import logging
import socket
import struct
import threading
import time
from datetime import datetime
from typing import Any, Union

import numpy as np

from .reader_base import CantFilterDataError, LSData, StatData

NumpyArray = np.ndarray # used for typehints


class LiveConnectConnectionFailedError(Exception):
    """ Error to be raised if the connect method in LiveConnect fails """


class LiveConnect(LSData):
    def __init__(self, port: int, host: str = "localhost") -> None:
        """ Reads LS data from a port on the given host
        
        Args:
            port: The TCP port to attempt connection to.
            host: The hostname/IP to connect to as a string (e.g. '127.0.0.1').

        User methods:
            update_loop()             :   Start the update loop.
            stop_loop()               :   Stop the update loop.
            connect()                 :   Connect to the socket. This is usually done automatically on object creation.
            disconnect()              :   Disconnect from and close the socket. To restart loop, connect() must be called first.
            search_sensors_full()     :   Searches the sensor dictionary and returns a dict of all matching names.
            search_sensors()          :   Searches the sensor dictionary and returns a list of all matching indices.
            print_sensorlist()        :   Prints out a list of the sensors with indices.
            print_connection_status() :   Prints info about the current connection

        Properties:
            sensorlist (no return)         :   Prints out a list of the sensors with indices.
            num_sensors (int)              :   Number of sensors.
            timevector (double[N])         :   Numpy array containing the time points for the data entries.
            timevector_days (double[N])    :   Same as timevector, but as days since initial time point.
            timevector_hours (double[N])   :   Same as timevector_days, but as hours.
            timevector_minutes (double[N]) :   Same as timevector_days, but as minutes.
            datamatrix (double[N,S])       :   Numpy matrix containing the data. N = num. data points. S = num. sensors.
            datamatrix (double[N,S,D])     :   Same as the other datamatrix, but for statistics data. D = which stat.
            datamatrix_bytesize (int)      :   Size of the entire datamatrix array in bytes.
            sensors (dict)                 :   Dictionary with the sensor names. Keys are indices, values are names.
            sensornames (list)             :   The names of all of the sensors in an ordered list.
        """
        self.logger = logging.getLogger(f"{__name__}.LiveConnect")
        self.logger.debug(f"Initializing")
        self._closed = True
        self._connected = False
        self._refused_connection = False
        self._loop_active = False
        self._port = port
        self._host = host
        self._data = None
        self._new_data_queue = []
        self._timevector = None
        self._datamatrix = None
        self._datalock = threading.Lock()
        self._new_data_lock = threading.Lock()
        self._conn_status = -1
        self.connect()

    def update_loop(self, append: bool = True, max_timesteps: Union[int, None] = None) -> None:
        """ Start the update loop and connection check loop. 
        
        The loops are started in separate threads.

        Acquires the thread lock to avoid changing the connection properties while they are accessed elsewhere.

        Args:
            append: if True, new data will be appended to a data matrix instead of overwriting old data.
            max_timesteps: Maximum number of timesteps to store in the data matrix, if None or zero, will store indefinitely (if append is True)
        """
        if not self._connected:
            self.logger.warning(f"{self._host}:{self._port} | Must connect before the update loop can be started...")
            return
        if not self._running:
            with self._datalock:
                self._running = True
                self._stopping = False
                self._last_updated = datetime.now()
                self._prev_check = datetime.now()
            self._append = append
            self._max_timesteps = max_timesteps
            threaded_update = threading.Thread(target=self._update_loop)
            check_connection = threading.Thread(target=self._check_still_connected)
            new_data_loop = threading.Thread(target=self._new_data_loop)
            threaded_update.start()
            check_connection.start()
            new_data_loop.start()
        else:
            self.logger.warning(f"{self._host}:{self._port} | Update loop is already running for this object.")        

    def stop_loop(self) -> None:
        """ Stop the update and connection check loops. 
        
        Acquires the thread lock to avoid changing the connection properties while they are accessed elsewhere.
        """
        self.logger.info("Stopping update loop, please wait...")
        with self._datalock:
            self._running = False
            self._stopping = True
            self._conn_status = 0
            self._failed_receives = 0

    def connect(self) -> None:
        """ Connect to the socket and read the header. 
        
        Acquires the thread lock to avoid changing connection properties while they are accessed elsewhere.
        """
        if not self._connected:
            with self._datalock:
                if self._closed:
                    try:
                        self._setup_connection_properties(self._port, self._host)
                        self._refused_connection = False
                    except ConnectionRefusedError as e:
                        self.logger.fatal(f"Connect failed, aborting. Error: {e}")
                        self._refused_connection = True
                        return
                self.logger.info(f"{self._host}:{self._port} | Connecting...")
                header_status = self._read_header()
                if header_status:
                    raise LiveConnectConnectionFailedError("Could not connect because the socket header was unavailable")
                self._data_buf = None
                self.total_data_read = 0 # amount of data we have read
                self.logger.info(f"{self._host}:{self._port} | Connected.")
                self._connected = True
                self.ownsocket.settimeout(2000)
                self._closed = False
        else:
            self.logger.info(f"{self._host}:{self._port} | Already connected.")

    def disconnect(self, force: bool = False) -> None:
        """ Stop the loops (if running) and disconnect from and close the socket.
        
        Acquires the thread lock to avoid changing connection properties while they are accessed elsewhere.

        Args:
            force (bool)    :   Force the socket to close without waiting for the loops to stop (default = False)
        """
        if self._loop_active and self._running:
            self.stop_loop()
        self.logger.info(f"{self._host}:{self._port} | Disconnecting, please wait...")
        if force:
            self.logger.warning(f"{self._host}:{self._port} | Forcing socket close without waiting...")
        while self._loop_active and not force:
            time.sleep(3)
        time.sleep(1)
        self.logger.info(f"{self._host}:{self._port} | Closing socket...")
        try:
            self.ownsocket.shutdown(socket.SHUT_RD)
            self.ownsocket.close()
        except OSError as e:
            self.logger.error(f"{self._host}:{self._port} | Could not disconnect due to OSError: {e} (might indicate the socket is already disconnected)")
        except AttributeError as e:
            pass
        
        with self._datalock:
            self._closed = True
            self._connected = False
        self.logger.info(f"{self._host}:{self._port} | Socket closed.")

    def reset_data(self) -> None:
        """ Reset the data matrix (can be used to clear it, to avoid data building up in memory) """
        with self._datalock:
            self._data = None
            self._new_data_queue = []
            self._timevector = None
            self._datamatrix = None

    def _setup_connection_properties(self, port: int, host: str) -> None:
        """ Setup connection properties
        
        Sets up the socket object and the properties required for keeping track
        of connection and data retrieval loop status.

        Args:
            port:   The TCP port to attempt connection to.
            host:   The hostname/IP to connect through as a string.
        """
        try:
            self.ownsocket = socket.create_connection((host, port), timeout=2)
        except socket.timeout as e:
            self.logger.error(f"{self._host}:{self._port} | Timeout error: {e}")
            return
        self._conn_status = 0
        self._failed_receives = 0
        self._running = False
        self._loop_active = False
        self._stopping = False
        self._conn_failure = False

    def _recv_int(self, flags: int = 0) -> int:
        """ Receive and return a single int from the connected socket
        
        Args:
            flags: Socket receive flags.

        Returns:
            data: Received value.
        """
        try:
            return struct.unpack("=i", self.ownsocket.recv(4, flags))[0]
        except socket.error as e:
            self.logger.error(f"{self._host}:{self._port} | Socket error: failure in _recv_int(): {e}")
        except struct.error as e:
            self.logger.error(f"{self._host}:{self._port} | Struct error: failure in _recv_int(): {e}")

    def _recv_bool(self, flags: int = 0) -> int:
        """ Receive and return a single bool/byte from the connected socket
        
        Args:
            flags: Socket receive flags.

        Returns:
            data: Received bool as an int
        """
        try:
            return struct.unpack("=B", self.ownsocket.recv(1, flags))[0]
        except socket.error as e:
            self.logger.error(f"{self._host}:{self._port} | Socket error: failure in _recv_bool(): {e}")
        except struct.error as e:
            self.logger.error(f"{self._host}:{self._port} | Struct error: failure in _recv_bool(): {e}")

    def _recv(self, recv_type: str, length: int, flags: int = 0) -> tuple:
        """ Receive, unpack and return any type and any length from the connected socket

        Note: this requires that the provided length is able to be received 
        
        Args:
            recv_type: Type to receive. E.g. "=i" for int, "=B" for single byte.
            length   : Number of bytes to receive.
            flags    : Socket receive flags.

        Returns:
            data:   Received data
        """
        try:
            return struct.unpack(recv_type, self.ownsocket.recv(length, flags))
        except socket.error as e:
            self.logger.error(f"{self._host}:{self._port} | Socket error: failure in _recv(): {e}")
        except struct.error as e:
            self.logger.error(f"{self._host}:{self._port} | Struct error: failure in _recv(): {e}")

    def _receive_data(self) -> int:
        """ Attempts to receive the remaining content of the next data block

        Acquires the thread lock for updating of class properties
        
        Retrieves and adds retrieved data to self._data_buf
        If no data is retrieved increments self._failed_receives

        Returns:
            remain: number of bytes remaining to read in the current data block
        """
        remain = self.total_data_size - self.total_data_read
        try:
            recv_data = self.ownsocket.recv(remain)
        except socket.timeout as e:
            recv_data = b""
            self.logger.error(f"{self._host}:{self._port} | Timeout error in receive loop: {e}")
        except OSError:
            self.logger.warning(f"{self._host}:{self._port} | OSerror when attempting to receive data, ignore if shutdown in progress.")

        if not self._running:
            return

        with self._datalock:
            if len(recv_data) <= 0:
                self._failed_receives += 1
            else:
                self._failed_receives = 0

            if self._data_buf is None:
                self._data_buf = recv_data
            else:
                self._data_buf += recv_data

            self.total_data_read = len(self._data_buf)
            remain = self.total_data_size - self.total_data_read

        return remain

    def _unpack_data(self, append: bool = True, max_timesteps: Union[int, None] = None) -> None:
        """ Unpacks the data buffer into a Numpy array with the data structure as described by the header
        
        self._unpackstring is generated by _read_header() based on the expected data types we receive

        Acquires the thread lock to avoid changing data while it is being accessed elsewhere

        Args:
            append: if True, the unpacked data block will be appended to the data retrieved up to this point
            max_timesteps: Maximum number of timesteps to store in the data matrix, if None or zero, will store indefinitely (if append is True)

        If append is False, the data retrieved up to this point will
        be overwritten (i.e. the data property will always hold the
        most recent data retrieved, but nothing before that)
        """
        if not self._running:
            return

        with self._datalock:
            try:
                new_data = struct.iter_unpack(self._unpackstring, self._data_buf)
            except struct.error as e:
                self.logger.error(f"{self._host}:{self._port} | Attempted reading data, but could not unpack. Am I in the middle of closing?\nError given was: {e}")
                return
            new_data = np.array(list(new_data))
            if self._data is None or not append:
                self._data = new_data
            else:
                try:
                    self._data = np.append(self._data, new_data, axis = 0)
                    if max_timesteps: # is not None or zero
                        if self._data.shape[0] > max_timesteps:
                            self._data = self._data[-max_timesteps:]
                except ValueError as e:
                    self.logger.warning(f"{self._host}:{self._port} | Data append failed (likely due to a connection problem).")
            if self._conn_status == 0 and not self._stopping:
                self._conn_status = 1
            self._last_updated = datetime.now()
            self._data_buf = None

            self._timevector = self._data[:,0]
            self._datamatrix = self._data[:,1:]

            if self.n_d == 2:
                self._datamatrix = np.reshape(self._datamatrix,
                                              (len(self._timevector),
                                               self.num_sensors,
                                               self.dims[1]))

    def _get_next(self, append: bool = True, max_timesteps: Union[int, None] = None) -> None:
        """ Retrieves the next datablock and calls _unpack_data() to add it to the data property of the object
        
        Acquires the thread lock to avoid changing certain properties while they are being accessed elsewhere.

        Args:
            append: If True, the unpacked data block will be appended to the data retrieved up to this point
            max_timesteps: Maximum number of timesteps to store in the data matrix, if None or zero, will store indefinitely (if append is True)
        """
        if not self._running:
            return

        with self._datalock:
            self.total_data_read = 0
            remain = self.total_data_size - self.total_data_read

        while remain and self._running:
            remain = self._receive_data()
            if self._failed_receives != 0:
                time.sleep(1) # if we have failed receives, wait one second
                              # before continuing to allow the connection
                              # time to recover.

        self._unpack_data(append, max_timesteps)
        if self.timevector is not None:
            with self._new_data_lock:
                self._new_data_queue.append((self.timevector[-self.packet_length:].copy(), self.datamatrix[-self.packet_length:].copy()))

    def on_new_data(self, t: NumpyArray, datablock: NumpyArray):
        """ Called when new data is received, with the last received block of time stamps and data as arguments
        
        By default empty. Functionality must be implemented in a subclass.

        Args:
            t - timevector for the received data block
            datablock - matrix containing the data for the received data block

        Note that depending on the packet length, multiple data entries may arrive at the same time.
        """

    def _new_data_loop(self):
        """ Runs a loop which calls on_new_data for each element of new data in the new_data_queue """
        while self._running or len(self._new_data_queue) > 0:
            with self._new_data_lock:
                while len(self._new_data_queue) > 0:
                    self.on_new_data(*self._new_data_queue.pop(0))
            time.sleep(1)

    def _check_still_connected(self) -> None:
        """ Connection check to kill the loop if we detect a connection failure

        Should run in a separate thread.

        Acquires the thread lock to avoid changing certain connection properties while they are accessed elsewhere.
        
        A connection failure will be detected if it takes more than an hour between successful data receives, or if
        three (by default) data receives in a row receive no bytes.
        """
        while self._running:
            stop_loop = False
            with self._datalock:
                self._prev_check = datetime.now()
                dt = datetime.now() - self._last_updated
                if dt.total_seconds() > 3600 and self._conn_status == 2:
                    self.logger.error(f"{self._host}:{self._port} | Timeout. No new data received in sixty minutes. Check connection.")
                    self._conn_failure = True
                    stop_loop = True
                if self._failed_receives >= 3:
                    self.logger.error(f"{self._host}:{self._port} | Three receives in a row failed. Check connection.")
                    self._conn_failure = True
                    stop_loop = True
            if stop_loop:
                self.stop_loop()
            time.sleep(10)

    def _update_loop(self) -> None:
        """ Main method for running the update loop. Should run in its own thread.
        
        Acquires the thread lock to avoid changing certain connection properties while they are accessed elsewhere.

        Automatically calls self.disconnect() in the event of a detected connection failure,
        to avoid leaving the connection to the socket open. This means the user must call .connect() on the object
        before the loop can be restarted.
        """
        self.logger.info(f"{self._host}:{self._port} | Starting update loop for port...")
        self.logger.info(f"{self._host}:{self._port} | Confirming connection by receiving first data block (this may take some time)...")
        self.logger.info(f"{self._host}:{self._port} | Will notify when data is ready.")
        while self._running:
            self._loop_active = True
            self._get_next(self._append, self._max_timesteps)
            if self._conn_status == 1:
                with self._datalock:
                    self._conn_status = 2
                    self.logger.info(f"{self._host}:{self._port} | Connection confirmed, data ready.")
        self._loop_active = False
        if self._conn_failure:
            self.logger.error(f"{self._host}:{self._port} | Disconnecting due to connection failure...")
            self.disconnect(force = True)
        self.logger.warning(f"{self._host}:{self._port} | Update loop stopped...")

    def _read_header(self) -> None:
        """ Read the connection header and set up the required properties for reading the data """
        self.logger.debug(f"{self._host}:{self._port} | Starting to read the header")
        packet_length = self._recv_int()
        if packet_length is None:
            self.logger.fatal(f"{self._host}:{self._port} | Connection failed, aborting. Is data being transmitted on the port?")
            return 1
        self.packet_length = packet_length
        self.flag_het = self._recv_bool() # flag for heterogeneous data
        self.sID = self._recv_int() # not used here
        self.flag_timeline = self._recv_bool() # flag for timeline data
        self.n_d = self._recv_int() # number of dimensions in use
        self.dims = self._recv("=4i", 16) # size of dimensions in use
        
        self.logger.debug(f"{self._host}:{self._port} | packet_length = {self.packet_length}")
        self.logger.debug(f"{self._host}:{self._port} | flag_het = {self.flag_het}")
        self.logger.debug(f"{self._host}:{self._port} | sID = {self.sID}")
        self.logger.debug(f"{self._host}:{self._port} | flag_timeline = {self.flag_timeline}")
        self.logger.debug(f"{self._host}:{self._port} | n_d = {self.n_d}")
        self.logger.debug(f"{self._host}:{self._port} | dims = {self.dims}")

        if self.flag_het:
            nE = self._recv_int()
            self.data_id = self._recv(f"={nE//4}i", nE)
            self.data_size = self._recv(f"={nE//4}i", nE)
        else:
            self.data_id = self._recv_int()
            self.data_size = self._recv_int()

        self.logger.debug(f"{self._host}:{self._port} | Reading sensor names")
        self._sensors = {}
        for i in range(self.num_sensors):
            # this code can be simplified with Python 3.8+:
            l = len(self.ownsocket.recv(256, socket.MSG_PEEK))
            while l < 256:
                self.logger.debug(f"{self._host}:{self._port} | Waiting for sensor name {i}, {l}/256 bytes received")
                time.sleep(0.001)
                l = len(self.ownsocket.recv(256, socket.MSG_PEEK))
            """ TODO: 3.8+ version
            while (l := len(self.ownsocket.recv(256, socket.MSG_PEEK))) < 256:
                print(f"Waiting for sensor name {i}, {l}/256 bytes received")
                time.sleep(0.001)
            """
            
            name = self._recv("=256s", 256)[0].split(b'\0',1)[0]
            name = name.decode('utf-8', errors="replace").replace('>', '') # sometimes sensor names include
                                                                           # this symbol for some reason
            self._sensors[i] = name
        
        self.logger.debug(f"{self._host}:{self._port} | Reading additional headers")
        self.header_count = self._recv_int()
        self.logger.debug(f"{self._host}:{self._port} | header_count = {self.header_count}")
        additional_headers = {}

        for i in range(self.header_count):
            header_size = self._recv_int()
            header_id = self._recv_int()
            l = len(self.ownsocket.recv(header_size, socket.MSG_PEEK))
            while l < header_size:
                self.logger.debug(f"{self._host}:{self._port} | Waiting for additional header block {i}, {l}/{header_size} bytes received")
                time.sleep(0.001)
                l = len(self.ownsocket.recv(header_size, socket.MSG_PEEK))
            """ TODO: 3.8+ version
            while (l := len(self.ownsocket.recv(header_size, socket.MSG_PEEK))) < header_size:
                print(f"Waiting for additional header block {i}, {l}/{header_size} bytes received")
                time.sleep(0.001)
            """

            header = self._recv(f"={header_size}s", header_size)[0].decode('utf-8')

            additional_headers[header_id] = header

        self.additional_headers = additional_headers
        
        if self.flag_het:
            self.logger.debug(f"{self._host}:{self._port} | Getting het datatype info")
            data_type = "".join([f"{x}" for x in self.data_id])
            # replace the numbers with corresponding type letter for unpacking with struct.unpack
            for i in range(10):
                data_type = data_type.replace(str(i), self._get_data_type(i))
            data_block_size = 8 + sum(self.data_size)
            self._unpackstring = f"=d{data_type}"
        else:
            self.logger.debug(f"{self._host}:{self._port} | Getting datatype info")
            if self.n_d == 1:
                data_block_size = self.flag_timeline*8 + self.num_sensors*self.data_size
                self._unpackstring = f"=d{self.num_sensors}{self._get_data_type(self.data_id)}"
            if self.n_d == 2:
                data_block_size = self.flag_timeline*8 + self.dims[1]*self.num_sensors*self.data_size
                self._unpackstring = f"=d{self.num_sensors*self.dims[1]}{self._get_data_type(self.data_id)}"

        self.data_block_size = data_block_size                      # single data block
        self.total_data_size = data_block_size*self.packet_length   # complete packages
        self.logger.debug(f"{self._host}:{self._port} | Header read complete")
        self.logger.debug(f"{self._host}:{self._port} | data_block_size = {self.data_block_size}")
        self.logger.debug(f"{self._host}:{self._port} | total_data_size = {self.total_data_size}")
        return 0

    def _get_data_type(self, data_id: int) -> str:
        """ Return a string representation of data type based on data_id
        
        Args:
            data_id: data ID int describing data type

        Returns:
            data_string_id: string representation for the given data type
        """
        if data_id == 1:
            return "s"
        elif data_id == 2:
            return "H"
        elif data_id == 8:
            return "f"
        elif data_id == 9:
            return "d"
        else:
            return ""

    def __enter__(self):
        self.update_loop()
        return self
    
    def __exit__(self, *args, **kwargs) -> None:
        self.disconnect(force = True)

    @property
    def refused_connection(self) -> bool:
        """ Returns True if the socket refused connection """
        return self._refused_connection

    @property
    def connection_active(self) -> bool:
        """ Returns True if the socket is active """
        return not self._closed

    @property
    def loop_running(self) -> bool:
        """ Returns True if the update loop is running """
        return self._loop_active

    @property
    def data_ready(self) -> bool:
        """ Returns True if data is ready on the connection """
        return self._conn_status == 2

    @property
    def num_sensors(self) -> int:
        return self.dims[0]

    @property
    def timevector(self) -> NumpyArray:
        """ Return the timevector
        
        Require the thread lock to avoid retrieving the timevector while data is being written elsewhere
        """
        with self._datalock:
            return super().timevector

    @property
    def datamatrix(self) -> NumpyArray:
        """ Return the timevector
        
        Require the thread lock to avoid retrieving the timevector while data is being written elsewhere
        """
        with self._datalock:
            return super().datamatrix

    @property
    def dataset(self) -> tuple:
        """ Return the timevector _and_ the datamatrix
        
        Require the thread lock to avoid retrieving the timevector while data is being written elsewhere
        """
        with self._datalock:
            return super().timevector, super().datamatrix

    @property
    def statobject(self) -> StatData:
        """ Create and return a StatData object with the latest data. 
        
        Acquires the thread lock so the data won't update between retrieving the timevector and datamatrix.
        """
        timevector, datamatrix = self.dataset    
        statobject = StatData(timevector,
                              datamatrix,
                              self.sensors)
        return statobject

    @property
    def statdata(self) -> StatData:
        return self.statobject

    def filter_data(self, *ignore) -> None:
        """ Does not work for live data """
        raise CantFilterDataError("filter_data() cannot be used on LiveConnect data.")

    def print_connection_status(self) -> None:
        """ Print info regarding the current status of the socket connection. """
        print(f"{self._host}:{self._port} | Connection status:")
        if self._closed:
            print(f"{self._host}:{self._port} | Socket closed, not active.")
        else:
            if self._conn_status == 0:
                print(f"{self._host}:{self._port} | Connected, not retrieving data.")
            elif self._conn_status == 1:
                print(f"{self._host}:{self._port} | Connected, this shouldn't happen (between states)")
            elif self._conn_status == 2:
                print(f"{self._host}:{self._port} | Connected, retrieving data.")
            print(f"{self._host}:{self._port} | Loop running status: {self._running}")
            print(f"{self._host}:{self._port} | Loop active status: {self._loop_active}")

    @property
    def packet_length(self) -> int:
        return self._packet_length

    @packet_length.setter
    def packet_length(self, value: int):
        if isinstance(value, int):
            self._packet_length = value
        else:
            raise ValueError("Attempted setting packet length with non-int")

    @property
    def flag_het(self) -> int:
        return self._flag_het

    @flag_het.setter
    def flag_het(self, value: int):
        if isinstance(value, int):
            self._flag_het = value
        else:
            raise ValueError("Attempted setting flag_het with non-int")

    @property
    def sID(self) -> int:
        return self._sID

    @sID.setter
    def sID(self, value: int):
        if isinstance(value, int):
            self._sID = value
        else:
            raise ValueError("Attempted setting sID with non-int")

    @property
    def flag_timeline(self) -> int:
        return self._flag_timeline

    @flag_timeline.setter
    def flag_timeline(self, value: int):
        if isinstance(value, int):
            self._flag_timeline = value
        else:
            raise ValueError("Attempted setting flag_timeline with non-int")

    @property
    def n_d(self) -> int:
        return self._n_d

    @n_d.setter
    def n_d(self, value: int):
        if isinstance(value, int):
            self._n_d = value
        else:
            raise ValueError("Attempted setting n_d with non-int")

    @property
    def dims(self) -> tuple:
        return self._dims

    @dims.setter
    def dims(self, value: tuple):
        if isinstance(value, tuple):
            self._dims = value
        else:
            raise ValueError("Attempted setting dims with non-tuple")

    @property
    def data_id(self) -> Union[int, tuple]:
        return self._data_id

    @data_id.setter
    def data_id(self, value: Union[int, tuple]):
        if isinstance(value, int) or isinstance(value, tuple):
            self._data_id = value
        else:
            raise ValueError("Attempted setting data_id with non-int or non-tuple")

    @property
    def data_size(self) -> Union[int, tuple]:
        return self._data_size

    @data_size.setter
    def data_size(self, value: Union[int, tuple]):
        if isinstance(value, int) or isinstance(value, tuple):
            self._data_size = value
        else:
            raise ValueError("Attempted setting data_size with non-int or non-tuple")

    @property
    def header_count(self) -> int:
        return self._header_count

    @header_count.setter
    def header_count(self, value: int):
        if isinstance(value, int):
            self._header_count = value
        else:
            raise ValueError("Attempted setting header_count with non-int")

    @property
    def data_block_size(self) -> int:
        return self._data_block_size

    @data_block_size.setter
    def data_block_size(self, value: int):
        if isinstance(value, int):
            self._data_block_size = value
        else:
            raise ValueError("Attempted setting data_block_size with non-int")

    @property
    def total_data_size(self) -> int:
        return self._total_data_size

    @total_data_size.setter
    def total_data_size(self, value: int):
        if isinstance(value, int):
            self._total_data_size = value
        else:
            raise ValueError("Attempted setting total_data_size with non-int")
