import glob
import os
import platform
import queue
import struct
import tarfile
import copy
from datetime import datetime, timezone, timedelta
from typing import Union, Tuple, List, Iterable

import numpy as np
import pandas as pd
from numpy.random import default_rng

RNG = default_rng()

try:
    import matplotlib.pyplot as plt
    matplotlib_installed = True
except ImportError:
    matplotlib_installed = False

try:
    import openpyxl
    openpyxl_installed = True
except ImportError:
    openpyxl_installed = False

try:
    import odf
    odfpy_installed = True
except ImportError:
    odfpy_installed = False

try:
    import tabulate
    tabulate_installed = True
except ImportError:
    tabulate_installed = False

NumpyArray = np.ndarray # used for typehints


class NotInstalledError(Exception):
    """ Raised if trying to use a package which is not installed """


class CantFilterDataError(Exception):
    """ Raised if trying to use filter_data on an object which does not support it """


class bcolors:
    """ For providing colors to terminal output on supported systems. """
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


class LSData:
    """ Superclass for common data reader methods with common properties and methods """
    @property
    def timevector(self) -> NumpyArray:
        return self._timevector

    @property
    def timevector_days(self) -> NumpyArray:
        """ Timevector as days after the first datapoint. """
        if len(self.timevector) == 0:
            return np.zeros(0, dtype=float)
        return (self.timevector - self.timevector[0])/86400

    @property
    def timevector_hours(self) -> NumpyArray:
        """ Timevector as hours after the first datapoint. """
        if len(self.timevector) == 0:
            return np.zeros(0, dtype=float)
        return (self.timevector - self.timevector[0])/3600

    @property
    def timevector_minutes(self) -> NumpyArray:
        """ Timevector as minutes after the first datapoint. """
        if len(self.timevector) == 0:
            return np.zeros(0, dtype=float)
        return (self.timevector - self.timevector[0])/60

    @property
    def timevector_seconds(self) -> NumpyArray:
        """ Timevector as seconds after the first datapoint. """
        if len(self.timevector) == 0:
            return np.zeros(0, dtype=float)
        return (self.timevector - self.timevector[0])

    @property
    def timevector_datetime(self) -> NumpyArray:
        """ Timevector as an array of Numpy datetime types """
        if self.timevector is None:
            return np.zeros(0, dtype="datetime64[us]")
        if len(self.timevector) == 0:
            return np.zeros(0, dtype="datetime64[us]")
        return (self.timevector*1e6).astype("datetime64[us]")
    
    @property
    def timevector_intervals(self) -> NumpyArray:
        """ A vector of intervals between time points in the time vector.

        The vector has length N-1 where N is the length of the time vector, matching timevector[1:].
        """
        if len(self.timevector) == 0:
            return np.zeros(0, dtype=float)
        return self.timevector[1:] - self.timevector[:-1]

    @property
    def timevector_datarate(self) -> NumpyArray:
        """ Data rate in Hz for the time vector.

        The vector has length N-1 where N is the length of the time vector, matching timevector[1:].
        """
        if len(self.timevector) == 0:
            return np.zeros(0, dtype=float)
        return 1/self.timevector_intervals

    @property
    def average_datarate(self) -> float:
        """ Returns the average data rate of the time vector. """
        if len(self.timevector) == 0:
            return np.zeros(0, dtype=float)
        return np.average(self.timevector_datarate)

    @property
    def median_time_interval(self) -> float:
        """ Returns the median of the intervals between points in the timevector.

        Given a reasonably complete dataset, without too many gaps, this should be
        close to the expected ideal for this data. 
        """
        if len(self.timevector_intervals) == 0:
            return np.zeros(0, dtype=float)
        return np.median(self.timevector_intervals)
    
    @property
    def data_available_intervals(self) -> list:
        """ A list of start-end pairs of times where data appears to exist. """
        return self._data_available_intervals
    
    @property
    def data_missing_intervals(self) -> list:
        """ A list of start-end pairs of times where data appears to NOT exist. """
        return self._data_missing_intervals
    
    def total_data_available_time(self) -> float:
        """ Return the total estimate of time there is valid data for, in seconds """
        if len(self.timevector) == 0:
            return 0
        s = self.data_available_intervals[0][1] - self.data_available_intervals[0][0]
        for d in self.data_available_intervals[1:]:
            s += d[1] - d[0]
        return s.item().total_seconds()
    
    def total_data_missing_time(self):
        """ Return the total estimate of time there is missing data for, in seconds """
        if len(self.data_missing_intervals) == 0:
            return 0
        if len(self.timevector) == 0:
            return 0
        s = self.data_missing_intervals[0][1] - self.data_missing_intervals[0][0]
        for d in self.data_missing_intervals[1:]:
            s += d[1] - d[0]
        return s.item().total_seconds()
    
    def data_available_at(self, t: Union[datetime, NumpyArray], show_progress: bool = False) -> Union[bool, NumpyArray]:
        """ Determine whether data is available at the passed time point(s)
        
        If there are many gaps in data availability, and many time points in t, this might take a long time.

        Args:
            t: a single datetime, or an array of datetimes, to consider

        Returns:
            a single bool, or an array of bools, indicating when data is available
        """
        if isinstance(t, Iterable):
            avail_array = np.full(len(t), False, dtype=bool)
            for i, interval in enumerate(self.data_available_intervals):
                if show_progress:
                    try:
                        print(f"Working: {i/(len(self.data_available_intervals) - 1)*100:>5.1f}%", end="\r")
                    except ZeroDivisionError:
                        pass
                avail_now = (interval[0] <= t) & (t <= interval[1])
                avail_array = avail_now | avail_array
            if show_progress:
                print(f"Working: {100:>5.1f}%")
            return avail_array
        else:
            for interval in self.data_available_intervals:
                if interval[0] <= t <= interval[1]:
                    return True
        return False

    @property
    def datamatrix(self) -> NumpyArray:
        return self._datamatrix

    @property
    def dataset(self) -> tuple:
        """ Return the timevector _and_ the datamatrix """
        return self.timevector, self.datamatrix

    @property
    def datamatrix_bytesize(self) -> int:
        return self.datamatrix.size*self.datamatrix.itemsize

    @property
    def sensors(self) -> dict:
        """ Returns the entire sensors dictionary. Key: index, value: name. """
        return self._sensors

    @property
    def sensornames(self) -> list:
        """ Returns the sensor names in an ordered list. """
        return list(self.sensors.values())

    @property
    def sensorlist(self) -> None:
        """ Prints a list of sensor indices and names. """
        self.print_sensorlist()

    def calculate_data_availability(self, silent_read: bool = False) -> None:
        """ Calculates the list of intervals where data is (or isn't) available. """
        if not silent_read:
            print("Calculating data availability intervals... [WAIT]", end="\r")
        ideal_time_interval = self.median_time_interval
        gaps = (self.timevector[1:] - self.timevector[:-1]) > ideal_time_interval*1.5
        if len(gaps) == 0:
            self._data_available_intervals = [[self.timevector_datetime[0], self.timevector_datetime[-1]]]
            return
        transition_down = self.timevector_datetime[:-1][gaps] + np.timedelta64(timedelta(seconds=ideal_time_interval)) # times where data goes from available to unavailable
        transition_up = self.timevector_datetime[1:][gaps] # times where data goes from unavailable to available
        """
        data _must_ be available at the first and last time point in the dataset, as this is what bounds the data
        so after the final transition up, there must always be data until the end timepoint

        and there must always be data from the start timepoint until the first transition down
        """
        data_available_intervals = [[self.timevector_datetime[0]]]
        for td, tu in zip(transition_down, transition_up):
            data_available_intervals[-1].append(td) # append transition down to the last pair in the intervals list
            data_available_intervals.append([tu]) # append a new pair to the intervals list, starting at current transition up
        data_available_intervals[-1].append(self.timevector_datetime[-1]) # append the final timepoint to the last pair
        self._data_available_intervals = data_available_intervals

        # same as above, but shifted by one in order to mark downtimes
        data_missing_intervals = []
        for td, tu in zip(transition_down, transition_up):
            data_missing_intervals.append([td, tu])
        self._data_missing_intervals = data_missing_intervals
        if not silent_read:
            print("Calculating data availability intervals... [DONE]")

    def filter_data(self, time_start: Union[str, datetime],
                          time_end: Union[str, datetime],
                          silent: bool = False) -> "LSData":
        """ Filters the timevector and datamatrix so that only data in the range [time_start, time_end) remain. 
        
        Returns a copy of the LSData object with the filtered dataset.
        """
        if len(self.timevector) == 0:
            # if no data, just return without changing anything
            if not silent:
                print(f"Attempted to filter an empty LSData object, returning unchanged copy")
            return copy.copy(self) # return a copy, so that we have the same behaviour as if there is data
        
        if isinstance(time_start, str):
            if len(time_start.split(" ")) == 1:
                time_start += " 00:00:00" # add a time if the user only provided a day
            try:
                time_start = datetime.strptime(time_start, '%Y-%m-%d %H:%M:%S.%f').replace(tzinfo = timezone.utc)
            except ValueError:
                time_start = datetime.strptime(time_start, '%Y-%m-%d %H:%M:%S').replace(tzinfo = timezone.utc)

        if isinstance(time_end, str):
            if len(time_end.split(" ")) == 1:
                time_end += " 23:59:59" # add a time if the user only provided a day
            try:
                time_end = datetime.strptime(time_end, '%Y-%m-%d %H:%M:%S.%f').replace(tzinfo = timezone.utc)
            except ValueError:
                time_end = datetime.strptime(time_end, '%Y-%m-%d %H:%M:%S').replace(tzinfo = timezone.utc)

        timestamp_start = datetime.timestamp(time_start)
        timestamp_end = datetime.timestamp(time_end)

        timevector, datamatrix = self.dataset

        inds_after_start = timevector >= timestamp_start
        inds_before_end = timevector < timestamp_end
        matching_inds = inds_after_start & inds_before_end
        
        new = copy.copy(self)
        new._timevector = timevector[matching_inds]
        new._datamatrix = datamatrix[matching_inds]
        new.calculate_data_availability(silent_read=silent)
        return new

    def regenerate_timevector(self, interval: float, time_start: Union[float, None, str] = None) -> None:
        """ Regenerate the timevector with a given interval between data points.
        
        Args:
            interval: interval between subsequent data points in seconds
            time_start (optional): UNIX timestamp to start the regeneration from, if none is given, the first value in the existing time vector will be used
        """
        if time_start is None:
            time_start = self.timevector[0]
        else:
            if isinstance(time_start, str):
                if len(time_start.split(" ")) == 1:
                    time_start += " 00:00:00" # add a time if the user only provided a day
                time_start = datetime.strptime(time_start, "%Y-%m-%d %H:%M:%S").replace(tzinfo = timezone.utc).timestamp()

        end = time_start + (len(self.timevector) - 1) * interval
        new_timevector = np.linspace(time_start, end, len(self.timevector))
        self._timevector = new_timevector.copy()

        ts = datetime.utcfromtimestamp(self.timevector[0])
        te = datetime.utcfromtimestamp(self.timevector[-1])
        print(f"Regenerating timevector:  {len(self.timevector)}  values from  {ts}  to  {te} ")

    def regenerate_timevector(self, interval: float, time_start: Union[float, None, str] = None) -> None:
        """ Regenerate the timevector with a given interval between data points.
        
        Args:
            interval: interval between subsequent data points in seconds
            time_start (optional): UNIX timestamp to start the regeneration from, if none is given, the first value in the existing time vector will be used
        """
        if time_start is None:
            time_start = self.timevector[0]
        else:
            if isinstance(time_start, str):
                if len(time_start.split(" ")) == 1:
                    time_start += " 00:00:00" # add a time if the user only provided a day
                time_start = datetime.strptime(time_start, "%Y-%m-%d %H:%M:%S").replace(tzinfo = timezone.utc).timestamp()

        end = time_start + (len(self.timevector) - 1) * interval
        new_timevector = np.linspace(time_start, end, len(self.timevector))
        self._timevector = new_timevector.copy()

        ts = datetime.utcfromtimestamp(self.timevector[0])
        te = datetime.utcfromtimestamp(self.timevector[-1])
        print(f"Regenerating timevector:  {len(self.timevector)}  values from  {ts}  to  {te} ")

    def print_sensorlist(self) -> None:
        """ Prints a list of sensor indices and names. """
        print("\n ## Sensors: ## ")
        for key, item in self.sensors.items():
            print(f"{key} {item}")

    def search_sensordict(self, in_str: str, in_dict: dict = None, case_sensitive: bool = True) -> dict:
        """ Old method name for backwars compat. """
        return self.search_sensors_full(in_str, in_dict, case_sensitive=case_sensitive)

    def search_sensors_full(self, in_str: str, in_dict: dict = None, case_sensitive: bool = True) -> dict:
        """ Returns all sensor entries where the name contains 'in_str' 
        
        Args:
            in_str:   string to use for searching, case sensitive
            in_dict:   dictionary to search, if None is provided, use self.sensors
        
        Returns:
            result:   dictionary containing the results of the search
        """
        if in_dict is None:
            in_dict = self.sensors
        result = {}

        if not case_sensitive:
            in_str = in_str.lower()

        for key, value in in_dict.items():
            if not case_sensitive:
                value_search = value.lower()
            else:
                value_search = value
            if in_str in value_search:
                result[key] = value

        return result

    def search_sensordict_list(self, in_str: str, in_dict: dict = None, case_sensitive: bool = True) -> list:
        """ Old method name for backwards compat """
        return self.search_sensors(in_str, in_dict, case_sensitive=case_sensitive)

    def search_sensors(self, in_str: str, in_dict: dict = None, full: bool = False, case_sensitive: bool = True) -> list:
        """ Returns a simple list of the sensor indices of the search results from search_sensordict
        
        Args:
            in_str: string to use for searching, case sensitive
            in_dict: dictionary to search, if None is provided, use self.sensors
            full: if True, return the full dictionary, if not (default) return just a list of indices
        
        Returns:
            result: sensor indices of all matching sensors
        """
        result = self.search_sensors_full(in_str, in_dict, case_sensitive=case_sensitive)
        if not full:
            result = list(result.keys())

        return result

    def plot(self, sensor: Union[int, str],
             time_start: float = 0,
             time_end: float = 3652500,
             stat: Union[int, str, list] = None,
             label: Union[str, list] = "",
             valid_threshold: int = 0,
             ax = None) -> None:
        """ Plot a line for the given sensor in the currently active figure.

        Requires matplotlib. If there is no active figure, plt.plot() will make a new one.

        Args:
            sensor: sensor index or name, if the name can apply to more than one sensor, chooses the first match

        Optional args:
            time_start: time point to begin plotting from (in days since first datapoint), default = 0 
            time_end: time point to end plotting at (in days since first datapoint), default = 3652500
            stat: int, str or list of either, which statistic(s) to plot for statistic data (e.g. [min, max, std]) (defaults to all)
            label: if string, 
            valid_threshold: 
        """
        if not matplotlib_installed:
            raise NotInstalledError("Matplotlib is not installed, can't create plot.")

        if len(self.datamatrix.shape) > 2:
            if stat is None:
                stat = range(9)
            elif not isinstance(stat, list):
                stat = [stat]
        else:
            stat = [0]

        if isinstance(sensor, str):
            sensor_search = self.search_sensors(sensor)
            if len(sensor_search) > 1:
                print(f"{sensor} refers to {len(sensor_search)} sensors")
                print(f"Only plotting first match: {self.sensors[sensor_search[0]]}")
            sensor = sensor_search[0]
        
        for i, stat_cur in enumerate(stat):
            if isinstance(label, list):
                label_cur = label[i]
            else:
                label_cur = label

            if isinstance(stat_cur, str):
                stat_cur = stat_cur.lower()
                statdict = {"numofobs": 0, "num_obs": 0,
                            "mean": 1, "average": 1, "avg": 1,
                            "std": 2, "sd": 2, "standard_dev": 2,
                            "skewness": 3, "skew": 3,
                            "kurtosis": 4, "kurt": 4,
                            "minimum": 5, "min": 5,
                            "maximum": 6, "max": 6,
                            "numupxings": 7, "upcrossings": 7,
                            "maxpeakpeak": 8, "maxpp": 8}
                stat_cur = statdict[stat_cur]
            td = self.timevector_days
            v1 = td >= time_start
            v2 = td <= time_end
            v = v1 & v2

            sensorname = self.sensors[sensor]
            label_cur = label_cur.replace("<name>", sensorname)

            if valid_threshold > 0 and len(self.datamatrix.shape) > 2:
                num_obs = self.datamatrix[:, sensor, 0]
                v3 = num_obs >= valid_threshold
                v = v & v3

            if stat_cur is not None and len(self.datamatrix.shape) > 2:
                data = self.datamatrix[v, sensor, stat_cur]
            else:
                data = self.datamatrix[v, sensor]
            td = td[v]

            if ax is None:
                plt.plot(td, data, label = label_cur)
            else:
                ax.plot(td, data, label = label_cur)
    
    def plot_info(self, title: str = None, xlabel: str = None, ylabel: str = None) -> None:
        if not matplotlib_installed:
            raise NotInstalledError("Matplotlib is not installed, can't create plot.")

        if xlabel:
            plt.xlabel(xlabel)
        if ylabel:
            plt.ylabel(ylabel)
        if title:
            plt.title(title)
        ax = plt.gca()
        legend_handles = ax.get_legend_handles_labels()
        if len(legend_handles[0]) > 0:
            plt.legend()

    def show(self, title: str = None, xlabel: str = None, ylabel: str = None) -> None:
        """ Show plots """
        if matplotlib_installed:
            self.plot_info(title, xlabel, ylabel)
            plt.show()
            plt.close("all")
        else:
            raise NotInstalledError("Matplotlib is not installed, can't create plot.")


class SensorStatObject:
    def __init__(self, name: str, data: NumpyArray):
        """ Data object for holding statistics information for an individual sensor. 
    
        Args:
            name              :   Name of the sensor.
            data (double[N,D]):   Data matrix with data for the given sensor. N is time points, D is which statistic.

        Properties:
            sensorstatus (float)        :   Returns the uptime for the sensor.
            name (str)                  :   Returns the name of the sensor.
            num_obs (int[N])            :   Number of observations.
            num_observations (int[N])   :   ----------||----------
            mean (double[N])            :   Average observations.
            average (double[N])         :   ---------||---------
            standard_dev (double[N])    :   Standard deviation observations.
            skewness (double[N])        :   Skewness observations.
            kurtosis (double[N])        :   Kurtosis observations.
            min (double[N])             :   Minimum observations.
            minimum (double[N])         :   ---------||---------
            max (double[N])             :   Maximum observations.
            maximum (double[N])         :   ---------||---------
            upcrossings (int[N])        :   Number of mean up-crossings.
            maxpeakpeak (double[N])     :   Max peak-peak value.
            shape (tuple[2])            :   Tuple describing the matrix shape. Should be (N, 9).
        """
        self._name = name
        self._data = data

    def __repr__(self):
        return f"<lsreader SensorStatObject for sensor {self._name} at {hex(id(self))}>"

    @property
    def sensorstatus(self) -> float:
        """ Ratio of entries where this sensor has observations """
        return len(self.num_observations[self.num_observations > 0])/len(self.num_observations)

    @property
    def name(self) -> str:
        return self._name

    @property
    def nobs(self) -> NumpyArray:
        """ Shorter form of the num_observations property """
        return self.num_observations

    @property
    def num_obs(self) -> NumpyArray:
        """ Shorter form of the num_observations property """
        return self.num_observations

    @property
    def num_observations(self) -> NumpyArray:
        return self._data[:,0]

    @property
    def mean(self) -> NumpyArray:
        """ Also allow using 'mean' as name for average """
        return self.average

    @property
    def avg(self) -> NumpyArray:
        """ Also allow using 'avg' as name for average """
        return self.average

    @property
    def average(self) -> NumpyArray:
        return self._data[:,1]

    @property
    def std(self) -> NumpyArray:
        return self.standard_dev

    @property
    def standard_dev(self) -> NumpyArray:
        return self._data[:,2]

    @property
    def skewness(self) -> NumpyArray:
        return self._data[:,3]

    @property
    def kurtosis(self) -> NumpyArray:
        return self._data[:,4]

    @property
    def min(self) -> NumpyArray:
        """ Shorter form of the minimum property """
        return self.minimum

    @property
    def minimum(self) -> NumpyArray:
        return self._data[:,5]

    @property
    def max(self) -> NumpyArray:
        """ Shorter form of the maximum property """
        return self.maximum

    @property
    def maximum(self) -> NumpyArray:
        return self._data[:,6]

    @property
    def upcrossings(self) -> NumpyArray:
        """ Number of mean up-crossings """
        return self._data[:,7]

    @property
    def maxpeakpeak(self) -> NumpyArray:
        return self._data[:,8]

    @property
    def shape(self) -> tuple:
        return self._data.shape

    def __getitem__(self, key) -> NumpyArray:
        return self._data[:,key]


class StatData(LSData):
    def __init__(self, timevector, datamatrix, sensors: dict) -> None:
        """ Holds data from statistics files.

        Object for holding data from LS statistics files, and providing
        useful methods for handling it to the user.

        Args:
            timevector (double[N])      :   timevector array from the Reader class.
            datamatrix (double[N,S,D])  :   datamatrix array from the Reader class.
            sensors                     :   sensors dictionary from the Reader class {indices: names}.

        User methods:
            add_sensor()            :   Adds a sensor with data to the internal structure.
            get_sensorstatus()      :   Returns sorted arrays of sensor indices, names and uptimes.
            print_sensorstatus()    :   Prints a list of sensors and indices together with the uptime of the sensor.
            print_sensorlist()      :   Prints out a list of the sensors with indices.

        Properties:
            sensors (dict)               :  Dictionary with the sensor names. Keys are indices, values are names.
            sensorlist (None)            :  Prints out a list of the sensors with indices.
            timevector (double[N])       :  Numpy array containing the time points for the data entries.
            timevector_days (double[N])  :  Same as timevector, but as days since initial time point.
            timevector_hours (double[N]) :  Same as timevector_days, but as hours.
        """
        self._timevector = timevector
        self._original_sensors_dict = sensors
        self._sensors = {}
        self._sensor_map = {}
        self._datamatrix = datamatrix

        for index, name in sensors.items():
            sensordata = SensorStatObject(name, datamatrix[:,index])
            self.add_sensor(sensordata, index)

    def add_sensor(self, sensordata: SensorStatObject, index: int = None) -> None:
        """ Adds a sensor with data to the internal data structure 
        
        Args:
            sensordata: SensorStatObject for a given sensor
            index     : Index of the given sensor.
            
        If None is provided as Index, it will take the next available number
        which is equal to or larger than the number of sensors added to the list.
        """
        if index is None:
            index = len(self._sensors)
            while index in self._sensors:
                index += 1
        name = sensordata.name
        if name in self._sensor_map:
            add_num = 1
            while f"name_{add_num}" in self._sensor_map:
                add_num += 1
            #print(f"Duplicate sensor name in sensor data, adding {index}: {name} as {name}_{add_num}")
            name = f"{name}_{add_num}"
        self._sensors[index] = name
        self._sensor_map[name] = sensordata

    def __getitem__(self, key: Union[str, int, slice]) -> SensorStatObject:
        """ Returns a SensorStatObject based on either a sensor index or a sensor name.
        
        Args:
            key (str, int, slice) :  The index or name of the desired sensor.

        Returns:
            SensorStatObject for the requested sensor.
        """
        if isinstance(key, int):
            # Return sensor object based on index
            name = self._sensors[key]
            retobj = self._sensor_map[name]
        elif isinstance(key, str):
            # Return sensor object based on name
            retobj = self._sensor_map[key]
        elif isinstance(key, slice):
            retobj = []
            for i in range(slice.start, slice.stop, slice.step):
                name = self._sensors[i]
                retobj.append(self._sensor_map[name])
        return retobj

    def get_sensorstatus(self, sort_by="") -> tuple:
        """ Calculates and sets up arrays of the sensors sorted by uptime. 
        
        Returns:
            names (str[n])      :   Array containing sorted sensor names
            uptimes (double[n]) :   Array containing sorted sensor uptimes
            indices (int[n])    :   Array containing sorted sensor indices
        """

        names = []
        indices = []
        uptimes = []
        for index, name in self._sensors.items():
            sensorobj = self._sensor_map[name]
            indices.append(index)
            names.append(name)
            uptimes.append(sensorobj.sensorstatus)

        indices = np.array(indices)
        names = np.array(names)
        uptimes = np.array(uptimes)

        if sort_by.lower() in ["names", "name"]:
            inds = np.argsort(names)
        elif sort_by.lower() in ["index", "indices"]:
            inds = np.argsort(indices)
        else:
            inds = np.argsort(uptimes)

        return names[inds], uptimes[inds], indices[inds]

    def get_sensorstatus_dict(self, sort_by="") -> dict:
        """ Return a dictionary with sensor uptime fraction, with the name for each sensor as key """
        names, uptimes, indices = self.get_sensorstatus(sort_by=sort_by)

        ret_dict = {}
        for name, uptime in zip(names, uptimes):
            ret_dict[name] = uptime

        return ret_dict

    def print_sensorstatus(self, sort_by="") -> None:
        """ Prints a sensorlist with sensor uptime sorted by uptime """
        names, uptimes, indices = self.get_sensorstatus(sort_by=sort_by)

        print(f"{'Idx':6s}  {'Sensor name':45s} {'Up pct':7s}")
        print("-"*77)
        for name, uptime, index in zip(names, uptimes, indices):
            if platform.system().lower() == "linux":
                if 0.05 < uptime < 0.9:
                    start_color = bcolors.WARNING
                    end_color = bcolors.ENDC
                elif uptime <= 0.05:
                    start_color = bcolors.FAIL
                    end_color = bcolors.ENDC
                else:
                    start_color = bcolors.OKGREEN
                    end_color = bcolors.ENDC
            else:
                start_color = ""
                end_color = ""
            print(f"{index:6d}  {name[:40]:40s} {start_color}{uptime*100:7.1f}{end_color}")

    def filter_data(self, time_start: Union[str, datetime],
                          time_end: Union[str, datetime]) -> "LSData":
        new: "StatData" = super().filter_data(time_start, time_end)
        new.__init__(new._timevector, new._datamatrix, new._original_sensors_dict)
        return new

    @property
    def sensorstatus(self) -> None:
        self.print_sensorstatus()


class ReaderBase(LSData):
    allowed_export_types = ("xlsx", "csv", "ods", "md", "h5")
    allowed_export_names = ("Excel files", "CSV files", "ODS files", "Markdown files", "HDF5 files")

    def __init__(self, directory: str = None, silent_load: bool = False, loading_from_npy: bool = False, sort_by_timevector: bool = True) -> None:
        """ Reads LS data files from a specified directory.
        
        Reads LS .bin and .tmp data files and stores the data internally as properties.
        Can read either timeseries data, homogeneous data or heterogeneous data.

        Args:
            directory           :   The path to the directory where the program will look for files (default CWD).
            silent_load         :   True suppresses some messages while searching the directory.
            loading_from_npy    :   Not used by user. True will indicate the object was loaded from npy files.
            sort_by_timevector  :   If True (default), the timevector and datmatrix will be sorted so time is always increasing

        For the directory, local or relative should work, but it may depend onwhether the program is used in Windows
        or Linux (it is tested in Linux).
        It does not check subfolders.

        Methods:
            clear_data()            :   Clears any loaded data vectors and matrices to prepare for reading.
            read()                  :   Reads files from the current directory within a given date range.
            np_save()               :   Saves loaded data as .npy files within a tarball for easier access later.
            np_load() [classmethod] :   Loads saved data from .npy files within a tarball. See method for details.
            print_header_info()     :   Prints the additional header info from all the read files in a nice way.
            search_sensors_full()   :   Searches the sensor dictionary and returns a dict of all matching names.
            search_sensors()        :   Searches the sensor dictionary and returns a list of all matching indices.
            print_sensorlist()      :   Prints out a list of the sensors with indices.

        Properties:
            sensorlist (no return)          :  Prints out a list of the sensors with indices.
            num_sensors (int)               :  Number of sensors.
            data_type (str)                 :  Either 'float4' or 'double8', depending on what the file header indicated.
            timevector (double[N])          :  Numpy array containing the time points for the data entries.
            timevector_days (double[N])     :  Same as timevector, but as days since initial time point.
            timevector_hours (double[N])    :  Same as timevector_days, but as hours.
            timevector_minutes (double[N])  :  Same as timevector_days, but as minutes.
            datamatrix (double[N,S])        :  Numpy matrix containing the data. N = num. data points. S = num. sensors.
            datamatrix (double[N,S,D])      :  Same as the other datamatrix, but for statistics data. D = which stat.
            datamatrix_bytesize (int)       :  Size of the entire datamatrix array in bytes.
            sensors (dict)                  :  Dictionary with the sensor names. Keys are indices, values are names.
            sensornames (list)              :  The names of all of the sensors in an ordered list.
            pd_table (Pandas DataFrame)     :  Pandas DataFrame object with the data.
            header_info (dict)              :  Extra header info from the files.        
        """

        self._directory_ok = False
        self._has_read_data = False
        self._sort_by_timevector = sort_by_timevector
        self._loading_from_npy = loading_from_npy
        self._initial_directory = os.getcwd()
        if directory is None:
            directory = os.getcwd() # search current working directory if none other was provided
        self._silent_load = silent_load
        self.directory = directory # sets the directory variable and automatically calls self._foldercheck

    def __repr__(self) -> str:
        try:
            num_files = self._num_files_found
        except AttributeError:
            num_files = "u.k."
        if not self._has_read_data:
            return f"<lsreader Reader object in '{self.directory}' ({num_files} files) (no files read yet) at {hex(id(self))}>"
        num_sensors = self.num_sensors
        num_files_read = self._num_files_read
        if num_files_read == 0: num_files_read = "u.k."
        return f"<lsreader Reader object in '{self.directory}' ({num_files_read}/{num_files} files read/found) ({num_sensors} sensors) (type={self._reading_type}) at {hex(id(self))}>"

    @classmethod
    def init(cls, directory: str = None, name_filter: str = "",
             time_start: str = "1900-01-01 00:00:00",
             time_end: str = "9000-01-01 00:00:00",
             sort_by_timevector: Union[None, bool] = None,
             skip_files: List[str] = [],
             silent: bool = False,
             prog_bar: bool = False) -> "ReaderBase":
        """ A single method for initializing the class instance and reading the data. 
        
        Args:
            directory   : The path to the directory where the program will look for files (default CWD).
            name_filter : Filter files by filename. Only reads files which begin with this string.
            time_start  : When to begin reading from. Time format: YYYY-MM-DD HH:MM:SS or YYYY-MM-DD.
            time_end    : Same as time_start, but when to stop reading.
            skip_files  : List of filenames to skip when reading.
            silent      : Bool, if True, don't print information while loading.
            prog_bar    : Bool, if True, print a progress bar while loading. Overrides silent_read.
        """
        if prog_bar:
            silent_read = True
        new_obj = cls(directory = directory, silent_load = silent)
        stat = new_obj.read(name_filter = name_filter,
                            time_start = time_start,
                            time_end = time_end,
                            sort_by_timevector=sort_by_timevector,
                            skip_files=skip_files,
                            silent_read=silent,
                            prog_bar=prog_bar)
        
        return new_obj

    def clear_data(self) -> None:
        """ Clears and sets up empty data structures for reading the data. """
        self._data = []
        self._data_arrays = {}
        self._sensor_dicts = {}
        self._timevector = []
        self._datamatrix = []
        self._timevector_argsort = []
        self._data_available_intervals = []
        self._data_missing_intervals = []
        self._all_read_files = []
        self._statobject = None
        self._file_headers = {}
        self._pd_table = None
        self._pd_table_has_simple_headers = False
        self._reading_stats = False
        self._reading_het = False
        self._reading_raw = False
        self._reading_type = ""
        self._num_files_read = 0
        self.num_sensors = None
        self.data_type = None
        self.header_info = {}
        self.sensors = {}

    def _get_metadata(self) -> dict:
        """ Gets the metadata for the instance and returns as a dict 
        
        Metadata includes things like whether the read type is raw, het or stat,
        num files read, etc.

        Returns:
            metadata: dict containing instance metadata
        """
        metadata = {"reading_stats": self._reading_stats,
                    "reading_raw": self._reading_raw,
                    "reading_het": self._reading_het,
                    "reading_type": self._reading_type,
                    "num_files_read": self._num_files_read,
                    "num_files_found": self._num_files_found,
                    "num_files_total": self._num_files_total,
                    "directory": self.directory,
                    "num_sensors": self.num_sensors,
                    "data_type": self.data_type,
                    "header_info": self.header_info,
                    "sensors": self.sensors,
                    "dims": self.dims,
                    "all_read_files": self.all_read_files}
        return metadata

    def _set_metadata(self, metadata: dict) -> None:
        """ Set the instance metadata from a metadata dict 
        
        Args:
            metadata: dictionary containing the metadata (as generated by _get_metadata())
        """
        if "reading_stats" in metadata: self._reading_stats = metadata["reading_stats"]
        if "reading_raw" in metadata: self._reading_raw = metadata["reading_raw"]
        if "reading_het" in metadata: self._reading_het = metadata["reading_het"]
        if "reading_type" in metadata: self._reading_type = metadata["reading_type"]
        if "num_files_read" in metadata: self._num_files_read = metadata["num_files_read"]
        if "num_files_found" in metadata: self._num_files_found = metadata["num_files_found"]
        if "num_files_total" in metadata: self._num_files_total = metadata["num_files_total"]
        if "directory" in metadata: self.directory = metadata["directory"]
        if "num_sensors" in metadata: self.num_sensors = metadata["num_sensors"]
        if "data_type" in metadata: self.data_type = metadata["data_type"]
        if "header_info" in metadata: self.header_info = metadata["header_info"]
        if "sensors" in metadata: self.sensors = metadata["sensors"]
        if "dims" in metadata: self.dims = metadata["dims"]
        if "all_read_files" in metadata: self._all_read_files = metadata["all_read_files"]

    def _print_if_not_silent(self, text, silent_read: bool = False, end: str = "\n"):
        """ Helping method to only print during the read process if silent_read is False """
        if not silent_read:
            print(text, end=end)

    def _check_pathname(self, pathname: str,
                        read_files: list,
                        name_filter: str = "",
                        time_start: Union[str, datetime] = "1900-01-01 00:00:00",
                        time_end: Union[str, datetime] = "9000-01-01 00:00:00") -> None:
        """ Update the read_files list if the pathname matches the filters """
        filename = os.path.split(pathname)[-1]
        if not filename.startswith(name_filter):
            return
        time_file = filename.split(".")[0].split("_")
        time_file = datetime.strptime(time_file[1] + time_file[2], "%Y%m%d%H%M%S") # get a datetime object representing the time in the filename
        if time_start <= time_file <= time_end:
            # add to the read_files list if the pattern matches
            read_files.append(pathname)

    def read(self, name_filter: str = "",
             time_start: Union[str, datetime] = "1900-01-01 00:00:00",
             time_end: Union[str, datetime] = "9000-01-01 00:00:00",
             sort_by_timevector: Union[None, bool] = None,
             _queue: queue = None,
             silent_read: bool = False,
             skip_files: List[str] = [],
             prog_bar: bool = False):
        """ Reads data from the provided directory in the given time interval.

        The data is stored in the internal variables:
        self._timevector : (N length array with time points)
        self._datamatrix : (NxS size array with data points [S is number of sensors])

        If statistics files are read, also stores the data in a statistics object:
        self._statobject

        All of these can be accessed as instance properties (self.timevector,
                                                             self.datamatrix
                                                             and self.statdata)

        Args:
            name_filter :   Filter files by filename. Only reads files which begin with this string.
            time_start  :   When to begin reading from. Time format: YYYY-MM-DD HH:MM:SS or YYYY-MM-DD.
            time_end    :   Same as time_start, but when to stop reading.
            _queue      :   Used for multithreading, default None.
            silent_read :   If True, mutes console output.
            skip_files  :   List of filenames to skip when reading.
            prog_bar    :   If True, prints a progress bar while loading. Overrides silent_read.
        
        By default reads from year 1900 to 9000, which should include all possible files, as long as we remember to
        update the program about 7000 years from now.

        Returns:
            self.statdata if reading stat files, otherwise None
        """
        self.clear_data() # clear data structures first,
                          # to allow reading in new data without issues
        if sort_by_timevector is not None:
            self._sort_by_timevector = sort_by_timevector
        queue = _queue
        if not self._directory_ok:
            print("Directory must be set up and contain data files before reading.")
            print("Did you try to read a folder without data files?")
            return
        
        if time_start != "1900-01-01 00:00:00" or time_end != "9000-01-01 00:00:00":
            print_time_filter = True
        else:
            print_time_filter = False

        if isinstance(time_start, str):
            if len(time_start.split(" ")) == 1:
                time_start += " 00:00:00" # add a time if the user only provided a day
            time_start = datetime.strptime(time_start, "%Y-%m-%d %H:%M:%S")

        if isinstance(time_end, str):
            if len(time_end.split(" ")) == 1:
                time_end += " 23:59:59" # add a time if the user only provided a day
            time_end = datetime.strptime(time_end, "%Y-%m-%d %H:%M:%S")

        if name_filter != "": self._print_if_not_silent(f"Only reading files beginning with '{name_filter}'", silent_read)
        if print_time_filter: self._print_if_not_silent(f"Filtering by time from {time_start} to {time_end}", silent_read)
        read_files = [] # list for files that are to actually be read,
                        # filtered by date & time
        for pathname in self._files: # loop through files and filter by name and time
            self._check_pathname(pathname, read_files, name_filter, time_start, time_end)

        if not read_files:
            for pathname in self._removed_files: # check in the removed files (i.e. smaller size duplicates) if no files matched the filters regularly
                self._check_pathname(pathname, read_files, name_filter, time_start, time_end)

        self._num_files_total = len(read_files)
        self._num_files_read = 0
        if queue is not None:
            queue.put(self._num_files_total)

        if self._num_files_total == 0:
            self._print_if_not_silent("No files matched given filters...", silent_read)
            return
        
        if skip_files:
            self._print_if_not_silent(f"Reader skipping {len(skip_files)} files", silent_read)
            for skip_file in skip_files:
                if skip_file in read_files:
                    read_files.remove(skip_file)

        if not self._file_headers:
            self._read_headers(read_files, silent_read=silent_read)

        for i, path in enumerate(read_files): # read all files from the list
            if queue is not None:
                queue.put(i)
            filename = os.path.split(path)[-1]
            if self._file_headers[filename]["skip"]:
                continue

            self._print_if_not_silent(f"Reading file {i + 1} of {self._num_files_total} - {os.path.split(path)[-1]}            ", silent_read=silent_read, end="\r")
            if prog_bar:
                progress = i/(len(read_files))*90
                print(f"Loading data: [{'#'*int(progress/2):50s}] {progress:.2f}%  ", end = "\r")
            
            if self._read_file(path, silent_read=silent_read): # read the file, return is True if success
                self._num_files_read += 1

        if self._num_files_read == 0:
            self._print_if_not_silent("Couldn't read any files (none were big enough)", silent_read)
            return
        else:
            self._print_if_not_silent(f"\n## Finished reading ##", silent_read)

        self._print_if_not_silent("Concatenating... [WAIT]", silent_read, end="\r")
        for num_sensors, data_array in self._data_arrays.items():
            data_array = np.concatenate(data_array, axis=0)
            self._data_arrays[num_sensors] = data_array
            if prog_bar:
                progress = 95
                print(f"Loading data: [{'#'*int(progress/2):50s}] {progress:.2f}%  ", end = "\r")
        self._print_if_not_silent("Concatenating... [DONE]", silent_read)

        self._combine_data(silent_read=silent_read)
        self._finalize_data(silent_read=silent_read)
        if prog_bar:
            progress = 100
            print(f"Loading data: [{'#'*int(progress/2):50s}] {progress:.2f}%  ")
        self._has_read_data = True
        self._all_read_files = read_files
        
        if self._reading_stats:
            return self.statdata

    def _read_headers(self, files: list, silent_read: bool = False) -> None:
        """ Read headers of files in the given list
        
        Args:
            files: list of files to read the headers of
        """
        self._print_if_not_silent(f"Reading headers... [{0.0:>3.1f}%]", silent_read=silent_read, end="\r")
        num_files = len(files)
        for i, filepath in enumerate(files):
            self._print_if_not_silent(f"Reading headers... [{i/num_files*100:>3.1f}%]", silent_read=silent_read, end="\r")
            skip = False
            filename = os.path.split(filepath)[-1]
            filesize = os.stat(filepath).st_size

            if filesize < 42:
                self._print_if_not_silent(f"\nFile {filename} is too small to read the header ({filesize} bytes)", silent_read)
                header = {"skip": True}
                self._file_headers[filename] = header
                continue

            with open(filepath, "rb") as infile:
                flag_het = struct.unpack("=B", infile.read(1))[0]
                sID = struct.unpack("=i", infile.read(4))[0]
                flag_timeline = struct.unpack("=B", infile.read(1))[0]
                n_d = struct.unpack("=i", infile.read(4))[0]
                dims = struct.unpack("=4i", infile.read(16))

                header_length = 26

                if flag_het:
                    nE = struct.unpack("=i", infile.read(4))[0]
                    data_id = struct.unpack(f"={nE//4}i", infile.read(nE))
                    data_size = struct.unpack(f"={nE//4}i", infile.read(nE))
                    header_length += (4 + nE*2)
                else:
                    nE = 4
                    data_id = struct.unpack("=i", infile.read(4))[0]
                    data_size = struct.unpack("=i", infile.read(4))[0]
                    header_length += 8

                num_sensors = dims[0]

                nameblock_size = struct.unpack("=i", infile.read(4))[0]
                header_length += 4

                if not nameblock_size/256 == num_sensors:
                    print(f"\nWarning: nameblock size is not Nsensors*256, instead: nameblock_size={nameblock_size}, Nsensors={num_sensors} (*256={num_sensors*256})\nThis is unexpected, read may fail")

                tag_block_broken = False
                sensors = {}
                for i in range(num_sensors):
                    try:
                        name = struct.unpack("=256s", infile.read(256))[0].split(b'\0',1)[0]
                    except Exception as e:
                        self._print_if_not_silent(f"\nError while getting sensor tags in file: '{filename}': {e}. Skipping file.", silent_read)
                        header = {"skip": True}
                        self._file_headers[filename] = header
                        tag_block_broken = True
                        break
                    header_length += 256
                    name = name.decode('utf-8', errors="replace").replace('>', '') # sometimes sensor names include
                                                                                   # this symbol for some reason
                    sensors[i] = name

                if tag_block_broken:
                    continue

                try:
                    header_count = struct.unpack("=i", infile.read(4))[0]
                    header_length += 4
                except Exception:
                    self._print_if_not_silent(f"\nFile {filename} has a broken header ({filesize} bytes)", silent_read)
                    header = {"skip": True}
                    self._file_headers[filename] = header
                    continue

                for i in range(header_count):
                    header_size = struct.unpack("=i", infile.read(4))[0]
                    header_id = struct.unpack("=i", infile.read(4))[0]
                    header_length += 8

                    blocks_256 = header_size/256 # assume either one large block, or several 256 byte blocks of strings
                    if blocks_256 % 1 == 0 and blocks_256 > 0:
                        for j in range(int(blocks_256)):
                            data = (struct.unpack(f"256s",
                                                  infile.read(256))[0]
                                                  .split(b'\0',1)[0].decode('utf-8'))
                            self.header_info[f"{filename}|{i}|{j}"] = [data, header_id]
                    else:
                        data = (struct.unpack(f"{header_size}s",
                                              infile.read(header_size))[0]
                                              .split(b'\0',1)[0].decode('utf-8'))

                        self.header_info[f"{filename}|{i}"] = [data, header_id]
                    header_length += header_size

            if n_d == 2:
                if self._reading_raw or self._reading_het:
                    self._print_if_not_silent(f"{filename} is stat file, but already reading raw or het. Skipping.", silent_read)
                    skip = True
                else:
                    self._reading_stats = True # 'stats' datasets are any datasets with two data dimensions, usually statistics, but could also be e.g. scopedata
                    self._reading_type = "stats"
            elif n_d == 1 and not flag_het:
                if self._reading_stats or self._reading_het:
                    self._print_if_not_silent(f"{filename} is raw file, but already reading stats or het. Skipping.", silent_read)
                    skip = True
                else:
                    self._reading_raw = True
                    self._reading_type = "raw"
            elif flag_het:
                if self._reading_stats or self._reading_raw:
                    self._print_if_not_silent(f"{filename} is het file, but already reading stats or raw. Skipping.", silent_read)
                    skip = True
                else:
                    self._reading_het = True
                    self._reading_type = "het"

            if not skip:
                # sometimes the number of sensors change in the datasets, so set up lists for now to collect
                # sets with the same number of sensors together
                if not num_sensors in self._data_arrays:
                    self._data_arrays[num_sensors] = []
                    self._sensor_dicts[num_sensors] = sensors
                else:
                    if sensors != self._sensor_dicts[num_sensors]:
                        if not silent_read:
                            self._print_sensor_mismatches(sensors, self._sensor_dicts[num_sensors])
                        self._sensor_dicts[num_sensors] = sensors # always update to match the latest version

            self.dims = dims
            header = {"length": header_length,
                      "flag_het": flag_het,
                      "sID": sID,
                      "flag_timeline": flag_timeline,
                      "n_d": n_d,
                      "dims": dims,
                      "nE": nE,
                      "data_id": data_id,
                      "data_size": data_size,
                      "sensors": sensors,
                      "skip": skip}
            self._file_headers[filename] = header
        self._print_if_not_silent(f"Reading headers... [{100.0:>3.1f}%]", silent_read)

    def _foldercheck(self) -> None:
        """ Search for files in self.directory which are .bin or .tmp files.

        Removes duplicates.

        Files list is stored as self._files
        """
        if not self._silent_load:
            print(f"Searching {self.directory} for files...")
        directory = self.directory
        binfiles = glob.glob(os.path.join(directory, "*.bin"))
        tmpfiles = glob.glob(os.path.join(directory, "*.tmp"))

        removed_files = set()

        if len(binfiles) == len(tmpfiles) == 0:
            # also try searching like this if no files were found
            # (sometimes, depending on OS, might work better)
            binfiles = glob.glob(os.path.join(os.getcwd(), "*.bin"))
            tmpfiles = glob.glob(os.path.join(os.getcwd(), "*.tmp"))

        duplicates = list(set([file_[:-4] for file_ in binfiles])
                          & set([file_[:-4] for file_ in tmpfiles]))       
        for path_base in duplicates:
            binfile = path_base + ".bin"
            tmpfile = path_base + ".tmp"
            binsize = os.stat(binfile).st_size
            tmpsize = os.stat(tmpfile).st_size
            if binsize >= tmpsize:
                tmpfiles.remove(tmpfile)
                removed_files.add(tmpfile)
            else:
                binfiles.remove(binfile)
                removed_files.add(binfile)

        filelist = binfiles + tmpfiles
        filelist.sort()

        if len(filelist) == 0:
            print("Found no data files in selected folder.")
            print("Please select a different folder by setting obj.directory = 'dir'")
            return

        self._files = filelist
        self._removed_files = removed_files
        self._directory_ok = True
        if not self._silent_load:
            print(f"Found {len(filelist)} files...")
        self._num_files_found = len(filelist)

    def _make_statobject(self) -> None:
        """ Creates a statobject from the timevector, datamatrix and sensor dict """
        self._statobject = StatData(self.timevector,
                                    self.datamatrix,
                                    self.sensors)

    def _read_file(self, pathname: str, silent_read: bool = False) -> bool:
        """ Reads data from a single file from the given pathname.
        
        Adds the data to the internal data list: self._data

        Args:
            pathname: Path to the file which is to be read now.

        Returns:
            result: True if file was read properly, False if not
        """
        filesize = os.stat(pathname).st_size
        filename = os.path.split(pathname)[-1]

        if filesize < 1:
            self._print_if_not_silent(f"\nFile {filename} is empty", silent_read)
            return False
        elif filesize < 42:
            self._print_if_not_silent(f"\nFile {filename} is too small to read ({filesize} bytes)", silent_read)
            return False

        with open(pathname, "rb") as infile:
            # struct.unpack returns a tuple, so must always get the first index to get the value of the variable
            header = self._file_headers[filename]
            flag_het = header["flag_het"]
            dims = header["dims"]

            reading_stats = self._reading_stats
            reading_het = self._reading_het

            num_sensors = dims[0]

            # detect data type
            data_id = header["data_id"]
            if not flag_het:
                if data_id == 8:
                    data_type = "float4"
                    data_sizes = header["data_size"]
                elif data_id == 9:
                    data_type = "double8"
                    data_sizes = header["data_size"]
            else:
                data_ids = data_id
                data_sizes = header["data_size"]
                data_type = "".join([f"{x}" for x in data_ids])
                # replace the numbers with corresponding type letter for unpacking with struct.unpack
                data_type = data_type.replace("2", "H").replace("8", "f").replace("9", "d")

            self.data_type = data_type
            
            if filesize < header["length"]:
                self._print_if_not_silent(f"\nFile {filename} is too small to read ({filesize} bytes)", silent_read)
                return False

            infile.read(header["length"]) # skip header

            # done reading the header. Assume we are now at the start of actual data,
            # and that the rest of the file only contains data
            all_data = infile.read()

            if len(all_data) < 8:
                self._print_if_not_silent("\nNot enough data in file to read", silent_read)
                self._print_if_not_silent(f"Content length: {len(all_data)}", silent_read)
                return False

            """ A test to see that we are actually at the start of data
            (i.e. that the header has been correctly processed).
            If we are, the first 8 bytes should encode a reasonable
            unix timestamp as a double. Check therefore that the first 8 bytes
            is a timestamp within the range of 1999-01-01 to 2200-01-01.
            """
            first_time = struct.unpack("=d", all_data[:8])[0]
            first_time = datetime.utcfromtimestamp(first_time)
            if (first_time < datetime(1970, 1, 1) or first_time > datetime(2200, 1, 1)):
                # if the time does not match the expected range,
                # ask the user if they want to read the file anyway
                print("\nWarning: First time in datablock outside expected range (1998-2200). Possible errors in file.")
                print(f"First timestamp: {first_time}")
                cont = str(input("Read the file anyway (yN)? > "))
                if cont.lower() == "y" or cont.lower() == "yes":
                    self._print_if_not_silent("Attempting to read file...", silent_read)
                else:
                    self._print_if_not_silent("Skipping file...", silent_read)
                    return False

            if reading_stats: # or really any dataset with two dimensions in addition to time
                if data_sizes != 4:
                    self._print_if_not_silent("\nIncorrect data size for stat file...", silent_read)
                    return False

                data_block_size = (8 + header["dims"][1]*num_sensors*data_sizes) # size of each individual data block
                nblocks = int(len(all_data)/data_block_size) # number of data blocks which fit in all_data
                all_data_size = nblocks*data_block_size # the length of all the data blocks
                                                        # which fit in all_data, combined

                if nblocks == 0:
                    self._print_if_not_silent("\nNot enough data in file to read", silent_read)
                    self._print_if_not_silent(f"Content length: {len(all_data)}", silent_read)
                    return False

                data_out = struct.iter_unpack(f"=d{num_sensors*header['dims'][1]}f",
                                              all_data[:all_data_size])
            elif reading_het:
                data_block_size = 8 + sum(data_sizes)
                nblocks = int(len(all_data)/data_block_size)
                all_data_size = nblocks*data_block_size

                if nblocks == 0:
                    self._print_if_not_silent("\nNot enough data in file to read", silent_read)
                    self._print_if_not_silent(f"Content length: {len(all_data)}", silent_read)
                    return False

                data_out = struct.iter_unpack(f"=d{data_type}",
                                              all_data[:all_data_size])
            else: # reading raw
                data_block_size = 8 + num_sensors*data_sizes
                nblocks = int(len(all_data)/data_block_size)
                all_data_size = nblocks*data_block_size

                if nblocks == 0:
                    self._print_if_not_silent("\nNot enough data in file to read", silent_read)
                    self._print_if_not_silent(f"Content length: {len(all_data)}", silent_read)
                    return False

                unpackstring = None
                if data_sizes == 4:
                    unpackstring = f"=d{num_sensors}f"
                elif data_sizes == 8:
                    unpackstring = f"=d{num_sensors}d"

                if unpackstring is not None:
                    data_out = struct.iter_unpack(unpackstring,
                                                  all_data[:all_data_size])
                else:
                    return False

            data_array = self._data_arrays[num_sensors]
            data = np.array(list(data_out))
            if len(data_array) == 0:
                data_array = [data]
            else:
                data_array.append(data)
            self._data_arrays[num_sensors] = data_array
            return True

    def _print_sensor_mismatches(self, sensors: dict, old_sensors: dict = None) -> None:
        """ Prints out the difference between self.sensors and a new sensor dictionary

        Args:
            sensors: The sensor dictionary to compare

        Optional:
            old_sensors: The sensor list to compare with. If None, compares with self.sensors
        """
        if old_sensors is None:
            old_sensors = self.sensors

        # print differences to the user
        print("\nMismatch in sensor data between files:")
        for d1, d2 in zip(old_sensors.items(), sensors.items()):
            # print all items from both dictionaries, with a highlight of the
            # items that are different
            c_start = ""
            c_end = ""
            if d1 != d2:
                # assuming Linux terminal supports colors, and others do not (TODO: should do a better check)
                if platform.system().lower() == "linux":
                    c_start = bcolors.WARNING
                    c_end = bcolors.ENDC
                else:
                    c_end = " <--- Has difference "
            print(f"{c_start}{d1[0]:>4d}: {d1[1]:>30s} | {d2[0]:>4d}: {d2[1]:>30s}{c_end}")

    def _combine_data(self, silent_read: bool = False) -> None:
        """ Combines the data from multiple data arrays into a single self._data array 
        
        If there are multiple data arrays of varying size, will attempt to combine to make sensor indices match, based
        on sensor names.
        """
        num_sensors_array = np.array(list(self._data_arrays.keys()))
        inds = np.argsort(num_sensors_array)
        num_sensors_array = num_sensors_array[inds][::-1]
        max_num_sensors = num_sensors_array[0]

        # use the dataset with the highest number of sensors as the main one
        self._data = self._data_arrays[max_num_sensors]
        main_sensordict = self._sensor_dicts[max_num_sensors]

        self.num_sensors = int(max_num_sensors)
        self.sensors = main_sensordict

        if len(num_sensors_array) > 1 and not silent_read:
            print("Files contain varying number of sensors, attempting to combine.")
            print(f"Found a total of {len(num_sensors_array)} different datasets.")
            for i, length in enumerate(num_sensors_array):
                print(f"Dataset {i:>3d}: Number of sensors = {length:>5d}  |  Data points = {len(self._data_arrays[length][:,0])}")

        for i, cur_num_sensors in enumerate(num_sensors_array[1:]):
            # append data arrays where there was a different number of sensors to the data array
            cur_data = self._data_arrays[cur_num_sensors]
            cur_sensors = self._sensor_dicts[cur_num_sensors]

            append_array = np.zeros((len(cur_data[:,0]), self._data.shape[1]))  # create array of zeroes which has the
                                                                                # right shape to append to self._data
            append_array[:,0] = cur_data[:,0] # fill the timevector from cur_data into the append array

            cur_data_no_timevector = cur_data[:,1:]
            append_array_no_timevector = append_array[:,1:]

            for ind_old, name in cur_sensors.items():
                sensor_match = self.search_sensors_full(name, main_sensordict)
                _indent = ""
                if len(sensor_match) > 1:
                    self._print_if_not_silent(f"## Found sensor '{name}' in multiple locations in main data set, moving to both. ##", silent_read)
                    _indent = "    "

                if self._reading_stats:
                    # if reading stats, each sensor has self.dims[1] entries starting at ind_old*self.dims[1] and ending at ind_old*self.dims[1] + self.dims[1]
                    ind_old_start = ind_old*self.dims[1]
                    ind_old_end = ind_old_start + self.dims[1]

                    old_data = cur_data_no_timevector[:, ind_old_start:ind_old_end]
                    for ind_new, main_name in sensor_match.items():
                        self._print_if_not_silent(f"{_indent}Moving '{name}' from index {ind_old} in dataset {i+1} to {ind_new} (name: {main_name}) in the main dataset (0)", silent_read)
                        ind_new_start = ind_new*self.dims[1]
                        ind_new_end = ind_new_start + self.dims[1]
                        append_array_no_timevector[:, ind_new_start:ind_new_end] = old_data
                else:
                    for ind_new, main_name in sensor_match.items():
                        old_data = cur_data_no_timevector[:, ind_old]
                        self._print_if_not_silent(f"{_indent}Moving '{name}' from index {ind_old} in dataset {i+1} to {ind_new} (name: {main_name}) in the main dataset (0)", silent_read)
                        append_array_no_timevector[:, ind_new] = old_data

            self._data = np.append(self._data, append_array, axis = 0)
        self._data_arrays = None # Set to none since we do not need it anymore
            
    def _finalize_data(self, silent_read: bool = False) -> None:
        """ Finalizes and sets up the data structures after reading data. """
        
        self._timevector = self._data[:,0]
        self._datamatrix = self._data[:,1:]

        num_timepoints = len(self._timevector)

        try:
            stat_dims = self.dims[1]
        except AttributeError:
            stat_dims = 9 # fall back to nine if we can't get the value from the dims property
                          # this is to retain backwards compatibility with Numpy files saved with earlier versions of the reader
        
        if self._reading_stats:
            self._datamatrix = np.reshape(self._datamatrix,
                                          (num_timepoints, self._num_sensors, stat_dims))
            
        self._timevector_argsort = self._timevector.argsort()
        if self._sort_by_timevector:
            # sort arrays so time always increases
            self._timevector = self._timevector[self._timevector_argsort]
            self._datamatrix = self._datamatrix[self._timevector_argsort]

        # calculate the data availability intervals
        self.calculate_data_availability(silent_read=silent_read)

        if self._reading_stats:
            # make the statobject after sorting
            self._make_statobject()

        ts = datetime.utcfromtimestamp(self._timevector[0])
        te = datetime.utcfromtimestamp(self._timevector[-1])

        datashape = self._datamatrix.shape
        dataMbytes = self._datamatrix.size*self._datamatrix.itemsize/1024**2
        if not silent_read:
            print(f"Time vector:  {num_timepoints}  values from  {ts}  to  {te} ")
            print(f"Shape of the data matrix: {datashape}. Size: {dataMbytes:.2f} MB\n")
        self._data = []

    def print_header_info(self) -> None:
        """ Prints header info in a human-readable way. """
        filename = None
        for key, item in self.header_info.items():
            key_split = key.split("|")
            f = key_split[0]
            if f != filename:
                filename = f
                print(f"\nHeader info from: {f}")
                print(f"  i   j   hdID  Data")
                print("--------------------")
            if len(key_split) == 2:
                print(f"{int(key_split[1]):>3d}        {int(item[1]):>3d}  {item[0]}")
            else:
                print(f"{int(key_split[1]):>3d} {int(key_split[2]):>3d}    {int(item[1]):>3d}  {item[0]}")

    def np_save(self, name: str) -> None:
        """ Saves the data in .npy files stored in a tarball archive.

        Args:
            name: The name to use for the project when saving.
        """
        metadata = np.array([self._get_metadata()], dtype = object)

        filename, extension = os.path.splitext(name)
        filename2, extension2 = os.path.splitext(filename)
        filename2 = filename2.replace("_meta", "")
        filename = filename2.replace("_data", "")

        name = os.path.split(filename)[-1]
        if extension == "" and extension2 == "":
            filename += ".tar.gz"

        data = np.append(self.timevector[np.newaxis].T, self.datamatrix.reshape(self.timevector.shape[0], -1), axis = 1)

        np.save(f"{name}_meta.npy", metadata, allow_pickle = True)
        np.save(f"{name}_data.npy", data)

        with tarfile.open(filename, "w:gz") as outfile:
            outfile.add(f"{name}_meta.npy")
            outfile.add(f"{name}_data.npy")

        os.remove(f"{name}_meta.npy")
        os.remove(f"{name}_data.npy")

    @classmethod
    def np_load(cls, name: str = None):
        """ Loads a Reader object with data from file.

        Args:
            name: The path to the project to be loaded.

        Returns:
            A Reader object containing the saved data.
        """
        if name is None:
            name = str(input("Enter the path to the project to load > "))
        
        filename, extension = os.path.splitext(name)
        filename2, extension2 = os.path.splitext(filename)
        filename2 = filename2.replace("_meta", "")
        filename = filename2.replace("_data", "")

        name_compat = name
        name = os.path.split(filename)[-1]
        if extension == "" and extension2 == "":
            filename += ".tar.gz"

        unpacked_from_tar = False
        if (os.path.isfile(filename)):
            with tarfile.open(filename, "r:gz") as infile:
                for fn in ["_meta.npy", "_data.npy"]:
                    infile.extract(f"{name}{fn}")
            unpacked_from_tar = True
        if not (os.path.isfile(f"{name}_meta.npy")
                and os.path.isfile(f"{name}_data.npy")):
            if (os.path.isfile(f"{name_compat}_meta.npy")
                    and os.path.isfile(f"{name_compat}_data.npy")):
                name = name_compat # revert to old path resolving if new fails
            else:
                print("Couldn't find requested project to load.")
                return

        metadata = np.load(f"{name}_meta.npy", allow_pickle = True)
        data = np.load(f"{name}_data.npy")

        if len(metadata) == 1:
            metadata = metadata[0]
            directory = metadata["directory"]
            modern_load = True
        elif len(metadata) == 6:
            # keeping this for backwards compatability
            directory, num_sensors, data_type, header_info, sensors, reading_stats = metadata
            modern_load = False
        else:
            print("Metadata contains unknown number of items. File corrupted?")
            return

        new_obj = cls(directory, silent_load = True, loading_from_npy = True)
        new_obj.clear_data()

        if modern_load:
            new_obj._set_metadata(metadata)
        else:
            new_obj.num_sensors = num_sensors
            new_obj.data_type = data_type
            new_obj.header_info = header_info
            new_obj.sensors = sensors
            new_obj._reading_stats = reading_stats

        new_obj._data = data
        new_obj._finalize_data()
        new_obj._has_read_data = True

        if unpacked_from_tar:
            for fn in ["_meta.npy", "_data.npy"]:
                os.remove(f"{name}{fn}")

        return new_obj

    def export(self, filename: str, export_type: str = None,
               sensor_index_filter: Union[int, list] = None,
               sensor_name_filter: Union[str, list] = None,
               stat_type_filter: Union[int, str, list] = None,
               key: str = "table",
               append: bool = True,
               simple_headers: bool = True,
               index: bool = True) -> None:
        """ Exports the loaded data as a specified file type.

        Args:
            filename: Filename to use for storing the data.

        Optional args:
            export_type: Specify a filetype to use. If not given will try to auto-detect from the filename extension.
            sensor_index_filter: Specify a filter for sensor indices. Can either be int or list of ints.
            sensor_name_filter: Specify a filter for sensor names. Can either be str or list of strs.
            stat_type_filter: Specify a filter statistic type. Can be str, int or list of either.
            key: If storing as HDF5, specify the key to use for the table we are storing (default 'table').
            append: If storing as HDF5, specify whether we are appending to a file or not (default True).
            simple_headers: Store with simple column headers (i.e. without sensor index and statistics type).
            index: Export with an index column as the first column.

        If filtering by stat type using strings, the following strings are allowed:
            0: 'num. of obs.'
            1: 'average'
            2: 'st. dev.'
            3: 'skewness'
            4: 'kurtosis'
            5: 'minimum'
            6: 'maximum'
            7: 'mean up-xings'
            8: 'max pk-pk'
        """
        if not self._has_read_data:
            print("Can't export because no data has been read.")
            return
        allowed_types = self.allowed_export_types
        extension = os.path.splitext(filename)[-1][1:] # get the extension without the period
        if export_type is not None:
            if export_type not in allowed_types:
                if extension not in allowed_types:
                    print(f"Invalid export_type given and could not detect from filename extension.\nAllowed types: {allowed_types}")
                    return
                else:
                    print(f"Invalid export_type given, but detected {extension} from filename.")
            if extension != export_type:
                filename += f".{export_type}"
        else:
            if extension in allowed_types:
                export_type = extension
            else:
                print(f"No export_type given and could not detect from filename extension.\nAllowed types: {allowed_types}")
                return
        
        if export_type == "ods" and not odfpy_installed:
            raise NotInstalledError("You need the Python package 'odfpy' to export as ods.\nIt can be installed with python -m pip install odfpy")
        if export_type == "xlsx" and not openpyxl_installed:
            raise NotInstalledError("You need the Python package 'openpyxl' to export as xlsx.\nIt can be installed with python -m pip install openpyxl")
        if export_type == "md" and not tabulate_installed:
            raise NotInstalledError("You need the Python package 'tabulate' to export as md.\nIt can be installed with python -m pip install tabulate")

        print(f"Exporting data to {filename}")
        print("Generating table...")
        table = self.pd_table

        ### Filters
        if not (sensor_index_filter is sensor_name_filter is stat_type_filter is None):
            print("Filtering table before export...")

        if (not stat_type_filter is None) and self._reading_stats:
            if isinstance(stat_type_filter, list):
                cols_final = []
                for stat_filter in stat_type_filter:
                    cols = [col for col in table.columns if f"({stat_filter})".lower() in col]
                    cols_final += cols
            else:
                cols_final = [col for col in table.columns if f"({stat_type_filter})".lower() in col]
            if not "time" in cols_final:
                cols_final = ["time"] + cols_final
            table = table[cols_final]        

        if not sensor_index_filter is None:
            if isinstance(sensor_index_filter, list):
                cols_final = []
                for index_filter in sensor_index_filter:
                    try:
                        # we only want indices
                        index_filter = int(index_filter)
                    except ValueError:
                        print(f"Couldn't use {index_filter} as an index filter, because it is not a number")
                        continue
                    cols = [col for col in table.columns if f"[{index_filter}]" in col]
                    cols_final += cols
            else:
                try:
                    # we only want indices
                    index_filter = int(sensor_index_filter)
                except ValueError:
                    print(f"Couldn't use {sensor_index_filter} as an index filter, because it is not a number")
                cols_final = [col for col in table.columns if f"[{index_filter}]" in col]
            if not "time" in cols_final:
                cols_final = ["time"] + cols_final
            table = table[cols_final]
        
        if not sensor_name_filter is None:
            cols_final = []
            if isinstance(sensor_name_filter, list):
                for name_filter in sensor_name_filter:
                    cols = [col for col in table.columns if name_filter in col]
                    cols_final += cols
            else:
                cols_final = [col for col in table.columns if sensor_name_filter in col]
            if not "time" in cols_final:
                cols_final = ["time"] + cols_final
            
            cols_final = list(dict.fromkeys(cols_final)) # convert to dict and back to list to remove duplicates
            table = table[cols_final] 

        original_column_headers = table.columns
        if simple_headers:
            new_column_headers = []
            for i, col in enumerate(table.columns):
                if i > 0:
                    col = col.split()
                    if self._reading_stats:
                        col = " ".join(col[2:-1]) # include everything from index 2 up to, but not including, the last element
                    else:
                        col = col[2]
                new_column_headers.append(col)

            table.columns = new_column_headers

        print("Saving table...")
        if export_type == "ods" or export_type == "xlsx":
            table.to_excel(filename, index = index)
        elif export_type == "md":
            table.to_markdown(filename, index = index)
        elif export_type == "h5":
            table.to_hdf(filename, key, append = append, index = index)
        elif export_type == "csv":
            table.to_csv(filename, index = index)

        table.columns = original_column_headers

    def filter_data(self, time_start: Union[str, datetime],
                          time_end: Union[str, datetime],
                          silent: bool = False) -> "ReaderBase":
        new: "ReaderBase" = super().filter_data(time_start, time_end, silent=silent)
        new._make_statobject()
        return new

    def anonymize(self) -> None:
        """ Anonymize the data by making all sensor names generic and shifting the timevector by a random amount. """
        new_sensor_dict = {}

        for i in self.sensors:
            new_sensor_dict[i] = f"Sensor{i:03d}"

        self.sensors = new_sensor_dict

        time_max = datetime(2023, 1, 1, tzinfo=timezone.utc).timestamp()
        sub_1 = self.timevector[-1] - time_max

        self._timevector -= sub_1 # first make the _final_ time point in the time vector be a set date (20230101)
        self._timevector -= RNG.random()*4e8 # next subtract a random amount of time in the interval [0, 4e8) seconds (between 0 and approx 12.68 years)

    @property
    def header_info(self) -> dict:
        return self._header_info

    @header_info.setter
    def header_info(self, value: dict):
        """ Sets the header_info property.
        
        Checks that the value is dict as expected.

        Args:
            value:   Value to set as header_info
        """
        if isinstance(value, dict) or value is None:
            self._header_info = value
        else:
            raise TypeError(f"Tried setting header info dict with type: {type(value)} (should be dict)")

    @property
    def directory(self) -> str:
        return self._directory

    @directory.setter
    def directory(self, value: str):
        """ Sets the directory property and calls _foldercheck() to examine the path. """
        self._directory = value
        if not self._loading_from_npy:
            assert os.path.isdir(value), f"Provided path is not a directory: {value}"
            self._foldercheck()

    @property
    def statobject(self) -> StatData:
        """ For backwards compatability. """
        return self.statdata

    @property
    def statdata(self) -> StatData:
        if not self._statobject is None:
            return self._statobject

    @property
    def num_sensors(self) -> int:
        return self._num_sensors

    @num_sensors.setter
    def num_sensors(self, value: int):
        """ Sets the num_sensors property value.
        
        Checks that the value is integer as expected.

        Args:
            value:   Value to set as num_sensors
        """
        if isinstance(value, int) or value is None:
            self._num_sensors = value
        else:
            raise TypeError(f"Tried setting num_sensors with type: {type(value)} (should be int)")

    @property
    def data_type(self) -> str:
        return self._data_type

    @data_type.setter
    def data_type(self, value: str):
        """ Sets the value of the data_type property. 
        
        Checks that the input is a string as expected.

        Args:
            value: String representation of the data type.
        """
        if isinstance(value, str) or value is None:
            self._data_type = value
        else:
            raise TypeError(f"Tried setting data_type with type: {type(value)} (should be str)")
        
    @property
    def timevector_argsort(self) -> NumpyArray:
        return self._timevector_argsort

    def get_dataframe(self, simple_headers: bool = False) -> pd.DataFrame:
        """ Generate a Pandas dataframe containing the data. """
        if self._pd_table is None or simple_headers != self._pd_table_has_simple_headers:
            data = np.append(self.timevector[np.newaxis].T,
                             self.datamatrix.reshape(self.timevector.shape[0], -1), axis = 1)
            # if the table is not yet made, make it
            # if it's already made, no need to remake, just return self._pd_table
            self._pd_table = pd.DataFrame(data)
            if not self._reading_stats:
                columns = ["time"]
                for key, name in self.sensors.items():
                    if simple_headers:
                        columns += [name]
                    else:
                        columns += [f"[{key}] : {name}"]
            else:
                columns = ["time"]
                for key, name in self.sensors.items():
                    if simple_headers:
                        prefix = ""
                        appendix = ["" for i in range(9)]
                    else:
                        prefix = f"[{key}] : "
                        appendix = ["(num. of obs.) (0)", "(average) (1)", "(st. dev.) (2)", "(skewness) (3)",
                                    "(kurtosis) (4)", "(minimum) (5)", "(maximum) (6)", "(mean up-xings) (7)",
                                    "(max pk-pk) (8)"]
                    columns += [f"{prefix}{name}{appendix[0]}",
                                f"{prefix}{name}{appendix[1]}",
                                f"{prefix}{name}{appendix[2]}",
                                f"{prefix}{name}{appendix[3]}",
                                f"{prefix}{name}{appendix[4]}",
                                f"{prefix}{name}{appendix[5]}",
                                f"{prefix}{name}{appendix[6]}",
                                f"{prefix}{name}{appendix[7]}",
                                f"{prefix}{name}{appendix[8]}"]
            self._pd_table.columns = columns
            self._pd_table_has_simple_headers = simple_headers
        return self._pd_table

    @property
    def pd_table(self) -> pd.DataFrame:
        """ Generate a Pandas dataframe containing the data. 
        
        Returns:
            self._pd_table: DataFrame containing all the data.
        """
        return self.get_dataframe()

    @property
    def sensors(self) -> dict:
        """ Returns the entire sensors dictionary. Key: index, value: name. """
        return super().sensors

    @sensors.setter
    def sensors(self, value: dict):
        """ Sets the entire sensors dictionary.
        
        Checks that the value provided is a dictionary.

        Args:
            value: Dictionary of indices and sensor names.
        """
        if isinstance(value, dict) or value is None:
            self._sensors = value
        else:
            raise TypeError(f"Tried setting sensors dict with type: {type(value)} (should be dict)")

    @property
    def num_files_found(self) -> int:
        return self._num_files_found

    @property
    def num_files_read(self) -> int:
        """ Returns the number of files which were read. """
        return self._num_files_read

    @property
    def num_files_skipped(self) -> int:
        """ Returns the number of files which were skipped during read. """
        return self._num_files_total - self._num_files_read

    @property
    def reading_type(self) -> str:
        return self._reading_type

    @property
    def ls(self) -> None:
        """ Print a list of all the files in the initialized directory """
        for file in self._files:
            print(file)

    @property
    def all_read_files(self) -> List[str]:
        return self._all_read_files
    
    @property
    def ls_loaded(self) -> None:
        """ Print a list of all the files that were actually loaded into the data matrix """
        for file in self.all_read_files:
            print(file)

    def __getitem__(self, key) -> Union[NumpyArray, StatData]:
        """ Allow indexing the Reader object.
        
        If reading time-series or heterogeneous data, or if the passed index
        is a tuple index as if the datamatrix itself is being indexed.

        Otherwise, index as if the StatData object is indexed.

        Args:
            key (valid index object): index to use for requesting an item from either datamatrix or statobject

        Returns:
            self.datamatrix[key] or self.statdata[key]
        """
        if self.statdata is None or isinstance(key, tuple):
            return self.datamatrix[key]
        else:
            return self.statdata[key]
